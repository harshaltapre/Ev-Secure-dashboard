/*
 * ThreatProtection.h - Real-time Threat Protection System
 * 
 * This system acts like an antivirus for EV charging, detecting and blocking
 * threats in real-time while providing admin control capabilities.
 */

#ifndef THREAT_PROTECTION_H
#define THREAT_PROTECTION_H

#include "EV_Secure_Config.h"
#include "SecurityMetrics.h"

// Threat Protection Levels
enum ThreatProtectionLevel {
  PROTECTION_DISABLED = 0,
  PROTECTION_LOW = 1,      // Basic monitoring
  PROTECTION_MEDIUM = 2,    // Enhanced detection
  PROTECTION_HIGH = 3,      // Maximum security
  PROTECTION_MAXIMUM = 4    // Lockdown mode
};

// Threat Blocking Actions
enum ThreatAction {
  ACTION_NONE = 0,
  ACTION_WARN = 1,          // Log warning only
  ACTION_ALERT = 2,         // Send alert to dashboard
  ACTION_BLOCK = 3,         // Block charging session
  ACTION_EMERGENCY = 4      // Emergency stop + lockdown
};

// Threat Categories
enum ThreatCategory {
  THREAT_CATEGORY_NONE = 0,
  THREAT_CATEGORY_ELECTRICAL = 1,    // Voltage/current anomalies
  THREAT_CATEGORY_PROTOCOL = 2,       // OCPP protocol attacks
  THREAT_CATEGORY_NETWORK = 3,        // Network intrusions
  THREAT_CATEGORY_POWER = 4,          // Power quality issues
  THREAT_CATEGORY_SECURITY = 5        // General security threats
};

// Threat Detection Result
struct ThreatDetectionResult {
  bool threatDetected;
  float threatLevel;           // 0.0 - 1.0
  ThreatCategory category;
  ThreatAction recommendedAction;
  String threatDescription;
  String mitigationSteps;
  unsigned long detectionTime;
  bool isBlocked;
  String blockReason;
};

// Threat Protection Statistics
struct ThreatProtectionStats {
  unsigned long totalScans;
  unsigned long threatsDetected;
  unsigned long threatsBlocked;
  unsigned long falsePositives;
  float averageThreatLevel;
  unsigned long lastThreatTime;
  String lastThreatType;
  bool systemHealthy;
};

class ThreatProtection {
public:
  // Constructor
  ThreatProtection();
  
  // Core Protection Methods
  bool initialize();
  ThreatDetectionResult scanForThreats(const SensorData& sensorData, const MLPrediction& mlResult);
  bool blockThreat(const ThreatDetectionResult& threat);
  bool allowCharging();
  
  // Protection Level Management
  void setProtectionLevel(ThreatProtectionLevel level);
  ThreatProtectionLevel getProtectionLevel() const { return _protectionLevel; }
  
  // Admin Controls
  bool enableProtection(bool enable);
  bool isProtectionEnabled() const { return _protectionEnabled; }
  void setAdminOverride(bool override);
  bool isAdminOverride() const { return _adminOverride; }
  
  // Threat Analysis
  ThreatDetectionResult analyzeThreat(const SensorData& sensorData, const MLPrediction& mlResult);
  String getThreatReport() const;
  ThreatProtectionStats getProtectionStats() const;
  
  // Real-time Monitoring
  void updateProtectionStatus();
  bool isChargingAllowed() const;
  String getBlockReason() const;
  
  // Dashboard Integration
  String getDashboardData() const;
  bool processAdminCommand(const String& command);
  
  // Threat History
  void logThreat(const ThreatDetectionResult& threat);
  String getThreatHistory() const;
  void clearThreatHistory();
  
private:
  // Protection State
  ThreatProtectionLevel _protectionLevel;
  bool _protectionEnabled;
  bool _adminOverride;
  bool _chargingBlocked;
  String _blockReason;
  unsigned long _lastScanTime;
  
  // Threat Detection Methods
  ThreatDetectionResult _detectElectricalThreats(const SensorData& sensorData);
  ThreatDetectionResult _detectProtocolThreats(const SensorData& sensorData, const MLPrediction& mlResult);
  ThreatDetectionResult _detectPowerThreats(const SensorData& sensorData);
  ThreatDetectionResult _detectSecurityThreats(const SensorData& sensorData, const MLPrediction& mlResult);
  
  // Threat Analysis
  ThreatAction _determineThreatAction(const ThreatDetectionResult& threat);
  bool _shouldBlockThreat(const ThreatDetectionResult& threat);
  String _generateThreatDescription(const ThreatDetectionResult& threat);
  String _generateMitigationSteps(const ThreatDetectionResult& threat);
  
  // Protection Statistics
  ThreatProtectionStats _stats;
  unsigned long _scanCount;
  unsigned long _threatCount;
  unsigned long _blockCount;
  float _threatLevelSum;
  
  // Threat History
  static const int MAX_THREAT_HISTORY = 50;
  ThreatDetectionResult _threatHistory[MAX_THREAT_HISTORY];
  int _threatHistoryIndex;
  int _threatHistoryCount;
  
  // Real-time Protection
  bool _realTimeProtection;
  unsigned long _lastProtectionUpdate;
  float _currentThreatLevel;
  bool _immediateBlockRequired;
  
  // Helper Methods
  void _updateProtectionStats(const ThreatDetectionResult& threat);
  void _logThreatEvent(const String& event);
  bool _checkProtectionThresholds(float threatLevel);
  void _executeThreatAction(const ThreatDetectionResult& threat);
};

// Global threat protection instance
extern ThreatProtection threatProtection;

#endif // THREAT_PROTECTION_H
