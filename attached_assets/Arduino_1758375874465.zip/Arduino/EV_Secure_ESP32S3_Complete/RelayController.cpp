/*
 * RelayController.cpp - Relay Control Implementation
 * 
 * This file implements the RelayController class for managing relay operations
 * in the EV-Secure system.
 */

#include "RelayController.h"

// Constructor
RelayController::RelayController() 
  : _initialized(false), _currentState(RELAY_OFF), _emergencyStopActive(false),
    _manualOverrideEnabled(false), _safetyLimitsEnabled(true), _lastStateChange(0),
    _lastEmergencyStopTime(0), _faultResetTime(0), _lastCurrent(0.0f), _lastVoltage(0.0f),
    _overcurrentDetected(false), _overcurrentStartTime(0) {
  _status.state = RELAY_OFF;
  _status.isHealthy = true;
  _status.emergencyStopActive = false;
  _status.manualOverride = false;
  _status.faultCount = 0;
  _status.lastStateChange = 0;
  _status.lastFault = "";
}

// Initialize relay controller
bool RelayController::init() {
  if (_initialized) {
    return true;
  }
  
  Serial.println("Initializing Relay Controller...");
  
  // Configure relay control pin
  pinMode(RELAY_CONTROL_PIN, OUTPUT);
  digitalWrite(RELAY_CONTROL_PIN, RELAY_ACTIVE_LOW ? HIGH : LOW);
  
  // Configure emergency stop pin
  pinMode(EMERGENCY_STOP_PIN, INPUT_PULLUP);
  
  // Initialize state
  _currentState = RELAY_OFF;
  _status.state = RELAY_OFF;
  _status.isHealthy = true;
  _status.emergencyStopActive = false;
  _status.manualOverride = false;
  _status.faultCount = 0;
  _status.lastStateChange = millis();
  _status.lastFault = "";
  
  _initialized = true;
  Serial.println("Relay Controller initialized successfully");
  return true;
}

// Set relay state
bool RelayController::setRelayState(RelayState state) {
  if (!_initialized) {
    return false;
  }
  
  // Check if state change is allowed
  if (!_canChangeState(state)) {
    Serial.println("State change not allowed");
    return false;
  }
  
  // Check safety interlocks
  if (!_checkSafetyInterlocks()) {
    Serial.println("Safety interlocks prevent state change");
    return false;
  }
  
  // Handle emergency stop
  if (_emergencyStopActive && state == RELAY_ON) {
    Serial.println("Cannot turn relay ON - emergency stop active");
    return false;
  }
  
  // Change relay state
  bool pinState = (state == RELAY_ON) ? !RELAY_ACTIVE_LOW : RELAY_ACTIVE_LOW;
  _writeRelayPin(pinState);
  
  // Update state tracking
  RelayState oldState = _currentState;
  _currentState = state;
  _lastStateChange = millis();
  
  // Update status
  _status.state = state;
  _status.lastStateChange = millis();
  
  // Log state change
  Serial.println("Relay state changed: " + String(oldState) + " -> " + String(state));
  
  // Debounce relay
  _debounceRelay();
  
  return true;
}

// Set relay ON
bool RelayController::setRelayOn() {
  return setRelayState(RELAY_ON);
}

// Set relay OFF
bool RelayController::setRelayOff() {
  return setRelayState(RELAY_OFF);
}

// Get current relay state
RelayState RelayController::getRelayState() {
  return _currentState;
}

// Get relay status
RelayStatus RelayController::getRelayStatus() {
  _updateRelayStatus();
  return _status;
}

// Emergency stop
bool RelayController::emergencyStop() {
  if (!_initialized) {
    return false;
  }
  
  Serial.println("EMERGENCY STOP ACTIVATED!");
  
  // Turn off relay immediately
  _writeRelayPin(RELAY_ACTIVE_LOW ? HIGH : LOW);
  _currentState = RELAY_EMERGENCY_STOP;
  _emergencyStopActive = true;
  _lastEmergencyStopTime = millis();
  
  // Update status
  _status.state = RELAY_EMERGENCY_STOP;
  _status.emergencyStopActive = true;
  _status.lastStateChange = millis();
  
  // Log emergency stop
  _logFault("Emergency stop activated");
  
  return true;
}

// Reset emergency stop
bool RelayController::resetEmergencyStop() {
  if (!_emergencyStopActive) {
    return true; // Already reset
  }
  
  // Check if enough time has passed since emergency stop
  if (millis() - _lastEmergencyStopTime < FAULT_RESET_TIME_MS) {
    Serial.println("Cannot reset emergency stop - wait " + String(FAULT_RESET_TIME_MS) + "ms");
    return false;
  }
  
  // Check safety conditions
  if (!_checkSafetyInterlocks()) {
    Serial.println("Cannot reset emergency stop - safety conditions not met");
    return false;
  }
  
  _emergencyStopActive = false;
  _status.emergencyStopActive = false;
  
  Serial.println("Emergency stop reset");
  return true;
}

// Check if emergency stop is active
bool RelayController::isEmergencyStopActive() {
  return _emergencyStopActive;
}

// Check if relay is healthy
bool RelayController::isRelayHealthy() {
  _updateRelayStatus();
  return _status.isHealthy;
}

// Enable manual override
void RelayController::enableManualOverride(bool enable) {
  _manualOverrideEnabled = enable;
  _status.manualOverride = enable;
  
  Serial.println("Manual override " + String(enable ? "enabled" : "disabled"));
}

// Check if manual override is enabled
bool RelayController::isManualOverrideEnabled() {
  return _manualOverrideEnabled;
}

// Check safety limits
void RelayController::checkSafetyLimits(float current, float voltage) {
  if (!_safetyLimitsEnabled) {
    return;
  }
  
  _lastCurrent = current;
  _lastVoltage = voltage;
  
  // Check overcurrent
  if (current > MAX_CURRENT_THRESHOLD) {
    _handleOvercurrent(current);
  } else {
    _overcurrentDetected = false;
    _overcurrentStartTime = 0;
  }
  
  // Check undervoltage
  if (voltage < VOLTAGE_MIN_THRESHOLD) {
    _handleUndervoltage(voltage);
  }
  
  // Check overvoltage
  if (voltage > VOLTAGE_MAX_THRESHOLD) {
    _handleOvervoltage(voltage);
  }
}

// Handle emergency stop button
void RelayController::handleEmergencyStopButton() {
  if (digitalRead(EMERGENCY_STOP_PIN) == LOW) {
    if (!_emergencyStopActive) {
      emergencyStop();
    }
  }
}

// Update status
void RelayController::updateStatus() {
  _updateRelayStatus();
}

// Reset faults
void RelayController::resetFaults() {
  _status.faultCount = 0;
  _status.lastFault = "";
  _faultHistory = "";
  _faultResetTime = millis();
  
  Serial.println("Faults reset");
}

// Get fault history
String RelayController::getFaultHistory() {
  return _faultHistory;
}

// Private methods

// Write to relay pin
void RelayController::_writeRelayPin(bool state) {
  digitalWrite(RELAY_CONTROL_PIN, state);
  delay(RELAY_DEBOUNCE_MS); // Debounce
}

// Read relay feedback
bool RelayController::_readRelayFeedback() {
  // This would read from a feedback pin if available
  // For now, return the expected state
  return (_currentState == RELAY_ON);
}

// Update relay status
void RelayController::_updateRelayStatus() {
  // Check relay health
  bool expectedState = (_currentState == RELAY_ON);
  bool actualState = _readRelayFeedback();
  
  if (expectedState != actualState) {
    _status.isHealthy = false;
    _logFault("Relay feedback mismatch");
  } else {
    _status.isHealthy = true;
  }
  
  // Update emergency stop status
  _status.emergencyStopActive = _emergencyStopActive;
  
  // Update manual override status
  _status.manualOverride = _manualOverrideEnabled;
}

// Log fault
void RelayController::_logFault(const String& faultReason) {
  _status.faultCount++;
  _status.lastFaultReason = faultReason;
  
  String timestamp = String(millis());
  _faultHistory += timestamp + ": " + faultReason + "\n";
  
  Serial.println("Relay fault: " + faultReason);
}

// Check safety interlocks
bool RelayController::_checkSafetyInterlocks() {
  // Check if safety conditions are met
  if (_emergencyStopActive) {
    return false;
  }
  
  if (_status.faultCount > 5) {
    return false; // Too many faults
  }
  
  // Add more safety checks here
  return true;
}

// Handle overcurrent
void RelayController::_handleOvercurrent(float current) {
  if (!_overcurrentDetected) {
    _overcurrentDetected = true;
    _overcurrentStartTime = millis();
    Serial.println("Overcurrent detected: " + String(current) + "A");
  }
  
  // If overcurrent persists for too long, emergency stop
  if (millis() - _overcurrentStartTime > OVERCURRENT_TIME_MS) {
    emergencyStop();
    _logFault("Overcurrent protection triggered: " + String(current) + "A");
  }
}

// Handle undervoltage
void RelayController::_handleUndervoltage(float voltage) {
  Serial.println("Undervoltage detected: " + String(voltage) + "V");
  _logFault("Undervoltage: " + String(voltage) + "V");
}

// Handle overvoltage
void RelayController::_handleOvervoltage(float voltage) {
  Serial.println("Overvoltage detected: " + String(voltage) + "V");
  emergencyStop();
  _logFault("Overvoltage protection triggered: " + String(voltage) + "V");
}

// Check if state change is allowed
bool RelayController::_canChangeState(RelayState newState) {
  // Check if state change is allowed
  if (_currentState == newState) {
    return true; // No change needed
  }
  
  // Check debounce time
  if (millis() - _lastStateChange < RELAY_DEBOUNCE_MS) {
    return false;
  }
  
  // Check if manual override is enabled
  if (_manualOverrideEnabled) {
    return true;
  }
  
  // Check safety conditions
  if (!_checkSafetyInterlocks()) {
    return false;
  }
  
  return true;
}

// Debounce relay
void RelayController::_debounceRelay() {
  delay(RELAY_DEBOUNCE_MS);
}
