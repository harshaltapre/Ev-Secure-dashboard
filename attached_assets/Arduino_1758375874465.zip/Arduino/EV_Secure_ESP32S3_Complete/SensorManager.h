/*
 * SensorManager.h - Sensor Reading and Management Library
 * 
 * This library handles all sensor readings for the EV-Secure system:
 * - Current sensor (ACS712 or INA226)
 * - Voltage sensor (ZMPT101B or voltage divider)
 * - Temperature sensor (DS18B20)
 * - Frequency calculation
 * 
 * Features:
 * - Multiple sensor support (ACS712, INA226, ZMPT101B, DS18B20)
 * - ADC calibration for accurate readings
 * - Filtering and averaging for stable readings
 * - Automatic sensor detection and configuration
 * - Error handling and sensor health monitoring
 * 
 * Usage:
 * 1. Initialize with SensorManager::init()
 * 2. Read sensors with SensorManager::readCurrent(), readVoltage(), etc.
 * 3. Get sensor data structure with SensorManager::getSensorData()
 */

#ifndef SENSOR_MANAGER_H
#define SENSOR_MANAGER_H

#include "EV_Secure_Config.h"
#include <Arduino.h>
#include <driver/adc.h>
#include <esp_adc_cal.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// Sensor types
enum SensorType {
  SENSOR_ACS712,
  SENSOR_INA226,
  SENSOR_ZMPT101B,
  SENSOR_VOLTAGE_DIVIDER,
  SENSOR_DS18B20
};

// Sensor configuration
struct SensorConfig {
  SensorType currentSensorType;
  SensorType voltageSensorType;
  bool temperatureSensorEnabled;
  float currentCalibrationFactor;
  float voltageCalibrationFactor;
  float temperatureOffset;
};

class SensorManager {
public:
  static bool init();
  static bool init(SensorConfig config);
  static float readCurrent();
  static float readVoltage();
  static float readTemperature();
  static float readFrequency();
  static float readPower();
  static SensorData getSensorData();
  static bool isSensorHealthy();
  static void calibrateSensors();
  static void setCalibrationFactors(float currentFactor, float voltageFactor);
  
private:
  static bool _initialized;
  static SensorConfig _config;
  static esp_adc_cal_characteristics_t _adc1_chars;
  static esp_adc_cal_characteristics_t _adc2_chars;
  static OneWire* _oneWire;
  static DallasTemperature* _tempSensor;
  
  // Sensor reading methods
  static float _readCurrentACS712();
  static float _readCurrentINA226();
  static float _readVoltageZMPT101B();
  static float _readVoltageDivider();
  static float _readTemperatureDS18B20();
  static float _calculateFrequency();
  
  // Helper methods
  static uint32_t _readADC(adc1_channel_t channel, int samples = 10);
  static uint32_t _readADC2(adc2_channel_t channel, int samples = 10);
  static void _setupADC();
  static void _setupI2C();
  static void _setupOneWire();
  static float _applyFilter(float newValue, float* filterBuffer, int bufferSize);
  
  // Filter buffers
  static float _currentFilterBuffer[10];
  static float _voltageFilterBuffer[10];
  static int _filterIndex;
};

#endif // SENSOR_MANAGER_H