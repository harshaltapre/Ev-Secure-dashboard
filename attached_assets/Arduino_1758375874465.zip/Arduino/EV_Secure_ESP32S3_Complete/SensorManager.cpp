/*
 * SensorManager.cpp - Sensor Reading and Management Implementation
 * 
 * This file implements the SensorManager class for handling sensor readings
 * in the EV-Secure system.
 */

#include "SensorManager.h"

// Static member initialization
bool SensorManager::_initialized = false;
SensorConfig SensorManager::_config = {
  SENSOR_ACS712,
  SENSOR_ZMPT101B,
  true,
  1.0,
  1.0,
  0.0
};
esp_adc_cal_characteristics_t SensorManager::_adc1_chars;
esp_adc_cal_characteristics_t SensorManager::_adc2_chars;
OneWire* SensorManager::_oneWire = nullptr;
DallasTemperature* SensorManager::_tempSensor = nullptr;
float SensorManager::_currentFilterBuffer[10] = {0};
float SensorManager::_voltageFilterBuffer[10] = {0};
int SensorManager::_filterIndex = 0;

bool SensorManager::init() {
  return init(_config);
}

bool SensorManager::init(SensorConfig config) {
  if (_initialized) {
    return true;
  }
  
  Serial.println("Initializing Sensor Manager...");
  
  _config = config;
  
  // Setup ADC
  _setupADC();
  
  // Setup I2C if using INA226
  if (_config.currentSensorType == SENSOR_INA226) {
    _setupI2C();
  }
  
  // Setup OneWire for temperature sensor
  if (_config.temperatureSensorEnabled) {
    _setupOneWire();
  }
  
  // Initialize filter buffers
  for (int i = 0; i < 10; i++) {
    _currentFilterBuffer[i] = 0;
    _voltageFilterBuffer[i] = 0;
  }
  
  _initialized = true;
  Serial.println("Sensor Manager initialized successfully");
  return true;
}

float SensorManager::readCurrent() {
  if (!_initialized) {
    return 0.0;
  }
  
  float current = 0.0;
  
  switch (_config.currentSensorType) {
    case SENSOR_ACS712:
      current = _readCurrentACS712();
      break;
    case SENSOR_INA226:
      current = _readCurrentINA226();
      break;
    default:
      Serial.println("Unknown current sensor type");
      return 0.0;
  }
  
  // Apply calibration factor
  current *= _config.currentCalibrationFactor;
  
  // Apply filtering
  current = _applyFilter(current, _currentFilterBuffer, 10);
  
  return current;
}

float SensorManager::readVoltage() {
  if (!_initialized) {
    return 0.0;
  }
  
  float voltage = 0.0;
  
  switch (_config.voltageSensorType) {
    case SENSOR_ZMPT101B:
      voltage = _readVoltageZMPT101B();
      break;
    case SENSOR_VOLTAGE_DIVIDER:
      voltage = _readVoltageDivider();
      break;
    default:
      Serial.println("Unknown voltage sensor type");
      return 0.0;
  }
  
  // Apply calibration factor
  voltage *= _config.voltageCalibrationFactor;
  
  // Apply filtering
  voltage = _applyFilter(voltage, _voltageFilterBuffer, 10);
  
  return voltage;
}

float SensorManager::readTemperature() {
  if (!_initialized || !_config.temperatureSensorEnabled) {
    return 25.0; // Default temperature
  }
  
  return _readTemperatureDS18B20() + _config.temperatureOffset;
}

float SensorManager::readFrequency() {
  return _calculateFrequency();
}

float SensorManager::readPower() {
  return readCurrent() * readVoltage();
}

SensorData SensorManager::getSensorData() {
  SensorData data;
  data.current = readCurrent();
  data.voltage = readVoltage();
  data.power = data.current * data.voltage;
  data.frequency = readFrequency();
  data.temperature = readTemperature();
  data.timestamp = millis();
  
  return data;
}

bool SensorManager::isSensorHealthy() {
  // Check if sensors are responding
  float current = readCurrent();
  float voltage = readVoltage();
  
  // Basic health checks
  if (isnan(current) || isnan(voltage)) {
    return false;
  }
  
  if (abs(current) > ACS712_MAX_CURRENT * 1.5) {
    return false; // Current sensor may be faulty
  }
  
  if (voltage > ZMPT101B_MAX_VOLTAGE * 1.5) {
    return false; // Voltage sensor may be faulty
  }
  
  return true;
}

void SensorManager::calibrateSensors() {
  Serial.println("Starting sensor calibration...");
  
  // Read multiple samples for calibration
  float currentSum = 0;
  float voltageSum = 0;
  int samples = 100;
  
  for (int i = 0; i < samples; i++) {
    currentSum += _readCurrentACS712();
    voltageSum += _readVoltageZMPT101B();
    delay(10);
  }
  
  float avgCurrent = currentSum / samples;
  float avgVoltage = voltageSum / samples;
  
  Serial.println("Calibration results:");
  Serial.println("Average Current: " + String(avgCurrent) + " A");
  Serial.println("Average Voltage: " + String(avgVoltage) + " V");
  
  // You can implement automatic calibration here
  // For now, just log the values
}

void SensorManager::setCalibrationFactors(float currentFactor, float voltageFactor) {
  _config.currentCalibrationFactor = currentFactor;
  _config.voltageCalibrationFactor = voltageFactor;
  
  Serial.println("Calibration factors updated:");
  Serial.println("Current factor: " + String(currentFactor));
  Serial.println("Voltage factor: " + String(voltageFactor));
}

// Private methods implementation

float SensorManager::_readCurrentACS712() {
  uint32_t adc_reading = _readADC(ADC1_CHANNEL_0);
  uint32_t voltage = esp_adc_cal_raw_to_voltage(adc_reading, &_adc1_chars);
  
  // Convert to current (A)
  float current = ((voltage / 1000.0) - ACS712_OFFSET) / (ACS712_SENSITIVITY / 1000.0);
  
  return current;
}

float SensorManager::_readCurrentINA226() {
  // INA226 implementation would go here
  // For now, return ACS712 reading
  return _readCurrentACS712();
}

float SensorManager::_readVoltageZMPT101B() {
  uint32_t adc_reading = _readADC2(ADC2_CHANNEL_1);
  uint32_t voltage = esp_adc_cal_raw_to_voltage(adc_reading, &_adc2_chars);
  
  // Apply calibration factor for ZMPT101B
  float acVoltage = voltage * ZMPT101B_CALIBRATION;
  
  return acVoltage;
}

float SensorManager::_readVoltageDivider() {
  uint32_t adc_reading = _readADC2(ADC2_CHANNEL_1);
  uint32_t voltage = esp_adc_cal_raw_to_voltage(adc_reading, &_adc2_chars);
  
  // Simple voltage divider calculation
  // Adjust the divider ratio based on your circuit
  float dividerRatio = 11.0; // 10k + 1k resistor divider
  float acVoltage = voltage * dividerRatio / 1000.0;
  
  return acVoltage;
}

float SensorManager::_readTemperatureDS18B20() {
  if (!_tempSensor) {
    return 25.0;
  }
  
  _tempSensor->requestTemperatures();
  float temperature = _tempSensor->getTempCByIndex(0);
  
  if (temperature == DEVICE_DISCONNECTED_C) {
    return 25.0; // Default temperature if sensor disconnected
  }
  
  return temperature;
}

float SensorManager::_calculateFrequency() {
  // Simple frequency calculation based on zero-crossing detection
  static unsigned long lastZeroCross = 0;
  static int zeroCrossCount = 0;
  static float frequency = FREQUENCY_NOMINAL; // Default frequency
  
  float voltage = readVoltage();
  
  // Detect zero crossing (simplified)
  if (abs(voltage) < 0.1 && lastZeroCross > 0) {
    unsigned long timeDiff = millis() - lastZeroCross;
    if (timeDiff > 0) {
      frequency = 1000.0 / timeDiff; // Convert to Hz
    }
    lastZeroCross = millis();
    zeroCrossCount++;
  }
  
  return frequency;
}

uint32_t SensorManager::_readADC(adc1_channel_t channel, int samples) {
  uint32_t adc_reading = 0;
  
  for (int i = 0; i < samples; i++) {
    adc_reading += adc1_get_raw(channel);
    delayMicroseconds(100);
  }
  
  return adc_reading / samples;
}

uint32_t SensorManager::_readADC2(adc2_channel_t channel, int samples) {
  uint32_t adc_reading = 0;
  int raw_reading = 0; // FIXED: Use int instead of uint32_t
  
  for (int i = 0; i < samples; i++) {
    adc2_get_raw(channel, ADC_WIDTH_BIT_12, &raw_reading); // FIXED: Pass int*
    adc_reading += raw_reading;
    delayMicroseconds(100);
  }
  
  return adc_reading / samples;
}

void SensorManager::_setupADC() {
  // Configure ADC1 for current sensor
  adc1_config_width(ADC_WIDTH_BIT_12);
  adc1_config_channel_atten(ADC1_CHANNEL_0, ADC_ATTEN_DB_11);
  
  // Configure ADC2 for voltage sensor
  adc2_config_channel_atten(ADC2_CHANNEL_1, ADC_ATTEN_DB_11);
  
  // Characterize ADC
  esp_adc_cal_characterize(ADC_UNIT_1, ADC_ATTEN_DB_11, ADC_WIDTH_BIT_12, 1100, &_adc1_chars);
  esp_adc_cal_characterize(ADC_UNIT_2, ADC_ATTEN_DB_11, ADC_WIDTH_BIT_12, 1100, &_adc2_chars);
  
  Serial.println("ADC configured successfully");
}

void SensorManager::_setupI2C() {
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
  Wire.setClock(400000); // 400kHz I2C clock
  
  Serial.println("I2C configured successfully");
}

void SensorManager::_setupOneWire() {
  _oneWire = new OneWire(TEMPERATURE_SENSOR_PIN);
  _tempSensor = new DallasTemperature(_oneWire);
  _tempSensor->begin();
  _tempSensor->setResolution(TEMP_SENSOR_RESOLUTION);
  
  Serial.println("OneWire temperature sensor configured");
}

float SensorManager::_applyFilter(float newValue, float* filterBuffer, int bufferSize) {
  // Simple moving average filter
  filterBuffer[_filterIndex] = newValue;
  _filterIndex = (_filterIndex + 1) % bufferSize;
  
  float sum = 0;
  for (int i = 0; i < bufferSize; i++) {
    sum += filterBuffer[i];
  }
  
  return sum / bufferSize;
}
