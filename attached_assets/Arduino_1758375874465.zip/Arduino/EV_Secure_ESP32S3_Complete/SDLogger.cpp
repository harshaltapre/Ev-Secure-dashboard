/*
 * SDLogger.cpp - SD Card Logging Implementation
 * 
 * This file implements the SDLogger class for data logging to SD card
 * in the EV-Secure system.
 */

#include "SDLogger.h"

// Static member initialization
bool SDLogger::_initialized = false;
bool SDLogger::_loggingEnabled = true;
int SDLogger::_logLevel = 2;
unsigned long SDLogger::_lastLogTime = 0;
unsigned long SDLogger::_logInterval = 1000;
String SDLogger::_logBuffer = "";

File SDLogger::_sensorLogFile;
File SDLogger::_mlLogFile;
File SDLogger::_eventLogFile;
File SDLogger::_alertLogFile;
File SDLogger::_errorLogFile;

bool SDLogger::init() {
  if (_initialized) {
    return true;
  }
  
  Serial.println("Initializing SD Card Logger...");
  
  // Initialize SPI for SD card
  SPI.begin(SD_SCK_PIN, SD_MISO_PIN, SD_MOSI_PIN, SD_CS_PIN);
  
  // Initialize SD card
  if (!SD.begin(SD_CS_PIN)) {
    Serial.println("SD Card initialization failed!");
    return false;
  }
  
  // Check SD card health
  if (!isSDCardHealthy()) {
    Serial.println("SD Card health check failed!");
    return false;
  }
  
  // Create log files
  _createLogFiles();
  
  _initialized = true;
  Serial.println("SD Card Logger initialized successfully");
  Serial.println("Free space: " + String(getFreeSpace()) + " bytes");
  
  return true;
}

void SDLogger::logSensorData(const SensorData& sensorData) {
  if (!_initialized || !_loggingEnabled) {
    return;
  }
  
  String logEntry = _formatSensorData(sensorData);
  _writeToFile(_sensorLogFile, logEntry);
}

void SDLogger::logMLPrediction(const MLPrediction& mlResult) {
  if (!_initialized || !_loggingEnabled) {
    return;
  }
  
  String logEntry = _formatMLPrediction(mlResult);
  _writeToFile(_mlLogFile, logEntry);
}

void SDLogger::logSystemEvent(const String& event) {
  logSystemEvent(event, false);
}

void SDLogger::logSystemState(SystemState state) {
  String stateStr = "";
  switch (state) {
    case STATE_IDLE: stateStr = "IDLE"; break;
    case STATE_READY: stateStr = "READY"; break;
    case STATE_CHARGING: stateStr = "CHARGING"; break;
    case STATE_SUSPICIOUS: stateStr = "SUSPICIOUS"; break;
    case STATE_LOCKDOWN: stateStr = "LOCKDOWN"; break;
    default: stateStr = "UNKNOWN"; break;
  }
  
  logSystemEvent("State changed to: " + stateStr, false);
}

void SDLogger::logThreatDetection(const MLPrediction& mlResult) {
  String threatLevel = String(mlResult.prediction * 100, 1) + "%";
  String confidence = String(mlResult.confidence * 100, 1) + "%";
  
  String alert = "THREAT_DETECTED";
  String details = "Level: " + threatLevel + ", Confidence: " + confidence;
  
  logAlert(alert, details);
}

void SDLogger::logAlert(const String& alertType, const String& details) {
  if (!_initialized || !_loggingEnabled) {
    return;
  }
  
  String logEntry = _formatAlert(alertType, details);
  _writeToFile(_alertLogFile, logEntry);
}

void SDLogger::logError(const String& error) {
  if (!_initialized) {
    return;
  }
  
  String timestamp = _formatTimestamp(millis());
  String logEntry = timestamp + " - ERROR: " + error + "\n";
  
  _writeToFile(_errorLogFile, logEntry);
}

void SDLogger::logSystemEvent(const String& event, bool isCritical) {
  if (!_initialized || !_loggingEnabled) {
    return;
  }
  
  String timestamp = _formatTimestamp(millis());
  String critical = isCritical ? "CRITICAL" : "INFO";
  String logEntry = timestamp + "," + critical + "," + event + "\n";
  
  _writeToFile(_eventLogFile, logEntry);
}

// File management
void SDLogger::rotateLogs() {
  if (!_initialized) {
    return;
  }
  
  Serial.println("Rotating log files...");
  
  // Close current files
  _sensorLogFile.close();
  _mlLogFile.close();
  _eventLogFile.close();
  _alertLogFile.close();
  _errorLogFile.close();
  
  // Create new files with timestamp
  String timestamp = String(millis());
  _sensorLogFile = SD.open(SENSOR_LOG_FILE + timestamp, FILE_WRITE);
  _mlLogFile = SD.open(ML_LOG_FILE + timestamp, FILE_WRITE);
  _eventLogFile = SD.open(EVENT_LOG_FILE + timestamp, FILE_WRITE);
  _alertLogFile = SD.open(ALERT_LOG_FILE + timestamp, FILE_WRITE);
  _errorLogFile = SD.open(ERROR_LOG_FILE + timestamp, FILE_WRITE);
  
  // Write headers to new files
  _writeCSVHeader(_sensorLogFile, "timestamp,current,voltage,power,frequency,temperature");
  _writeCSVHeader(_mlLogFile, "timestamp,prediction,confidence,anomaly_type");
  _writeCSVHeader(_eventLogFile, "timestamp,level,event");
  _writeCSVHeader(_alertLogFile, "timestamp,alert_type,details");
  
  Serial.println("Log files rotated successfully");
}

void SDLogger::cleanupOldLogs() {
  if (!_initialized) {
    return;
  }
  
  Serial.println("Cleaning up old log files...");
  
  // This is a simplified cleanup - in a real implementation,
  // you would iterate through files and delete old ones
  // based on file size, age, or count limits
}

void SDLogger::uploadPendingLogs() {
  if (!_initialized) {
    return;
  }
  
  // This would implement uploading logs to a server
  // For now, just log that upload was attempted
  logSystemEvent("Log upload attempted", false);
}

bool SDLogger::isSDCardHealthy() {
  if (!SD.begin(SD_CS_PIN)) {
    return false;
  }
  
  // Check if we can write to the card
  File testFile = SD.open("test.txt", FILE_WRITE);
  if (!testFile) {
    return false;
  }
  
  testFile.println("Health check");
  testFile.close();
  
  // Check if we can read from the card
  testFile = SD.open("test.txt", FILE_READ);
  if (!testFile) {
    return false;
  }
  
  testFile.close();
  SD.remove("test.txt");
  
  return true;
}

size_t SDLogger::getFreeSpace() {
  if (!_initialized) {
    return 0;
  }
  
  // This is a simplified implementation
  // In a real implementation, you would calculate actual free space
  return 1000000; // Return 1MB as placeholder
}

void SDLogger::formatSDCard() {
  if (!_initialized) {
    return;
  }
  
  Serial.println("Formatting SD card...");
  // Note: SD.format() is not available in all Arduino SD libraries
  // This would need to be implemented based on your specific library
  logSystemEvent("SD card format requested", true);
}

// Configuration
void SDLogger::setLogLevel(int level) {
  _logLevel = level;
  logSystemEvent("Log level set to: " + String(level), false);
}

void SDLogger::enableLogging(bool enable) {
  _loggingEnabled = enable;
  logSystemEvent("Logging " + String(enable ? "enabled" : "disabled"), false);
}

void SDLogger::setLogInterval(unsigned long interval) {
  _logInterval = interval;
  logSystemEvent("Log interval set to: " + String(interval) + "ms", false);
}

// Private methods
bool SDLogger::_writeToFile(File& file, const String& data) {
  if (!file) {
    return false;
  }
  
  file.print(data);
  file.flush();
  
  // Check file size and rotate if necessary
  if (_checkFileSize(file)) {
    rotateLogs();
  }
  
  return true;
}

String SDLogger::_formatTimestamp(unsigned long timestamp) {
  return String(timestamp);
}

String SDLogger::_formatSensorData(const SensorData& sensorData) {
  String data = _formatTimestamp(sensorData.timestamp) + ",";
  data += String(sensorData.current, 3) + ",";
  data += String(sensorData.voltage, 1) + ",";
  data += String(sensorData.power, 1) + ",";
  data += String(sensorData.frequency, 1) + ",";
  data += String(sensorData.temperature, 1) + "\n";
  
  return data;
}

String SDLogger::_formatMLPrediction(const MLPrediction& mlResult) {
  String data = _formatTimestamp(mlResult.timestamp) + ",";
  data += String(mlResult.prediction, 4) + ",";
  data += String(mlResult.confidence, 4) + ",";
  data += String(mlResult.anomalyType) + "\n";
  
  return data;
}

String SDLogger::_formatSystemEvent(const String& event, SystemState state) {
  String timestamp = _formatTimestamp(millis());
  String stateStr = String(state);
  return timestamp + "," + stateStr + "," + event + "\n";
}

String SDLogger::_formatAlert(const String& alertType, const String& details) {
  String timestamp = _formatTimestamp(millis());
  return timestamp + "," + alertType + "," + details + "\n";
}

void SDLogger::_flushBuffer() {
  if (_logBuffer.length() > 0) {
    // Flush buffer to appropriate files
    _logBuffer = "";
  }
}

bool SDLogger::_checkFileSize(File& file) {
  if (!file) {
    return false;
  }
  
  return file.size() > MAX_LOG_FILE_SIZE;
}

void SDLogger::_createLogFiles() {
  // Create sensor log file
  _sensorLogFile = SD.open(SENSOR_LOG_FILE, FILE_WRITE);
  if (_sensorLogFile) {
    _writeCSVHeader(_sensorLogFile, "timestamp,current,voltage,power,frequency,temperature");
  }
  
  // Create ML log file
  _mlLogFile = SD.open(ML_LOG_FILE, FILE_WRITE);
  if (_mlLogFile) {
    _writeCSVHeader(_mlLogFile, "timestamp,prediction,confidence,anomaly_type");
  }
  
  // Create event log file
  _eventLogFile = SD.open(EVENT_LOG_FILE, FILE_WRITE);
  if (_eventLogFile) {
    _writeCSVHeader(_eventLogFile, "timestamp,level,event");
  }
  
  // Create alert log file
  _alertLogFile = SD.open(ALERT_LOG_FILE, FILE_WRITE);
  if (_alertLogFile) {
    _writeCSVHeader(_alertLogFile, "timestamp,alert_type,details");
  }
  
  // Create error log file
  _errorLogFile = SD.open(ERROR_LOG_FILE, FILE_WRITE);
  if (_errorLogFile) {
    _errorLogFile.println("Error Log Started - " + _formatTimestamp(millis()));
  }
}

void SDLogger::_writeCSVHeader(File& file, const String& headers) {
  if (file) {
    file.println(headers);
    file.flush();
  }
}
