/*
 * RelayController.h - Relay Control Library
 * 
 * This library handles relay control for the EV-Secure system.
 * It provides safe charging control with safety interlocks and monitoring.
 */

#ifndef RELAY_CONTROLLER_H
#define RELAY_CONTROLLER_H

#include "EV_Secure_Config.h"

// Relay states
enum RelayState {
  RELAY_OFF,
  RELAY_ON,
  RELAY_EMERGENCY_STOP,
  RELAY_FAULT
};

// Relay status structure
struct RelayStatus {
  RelayState state;
  bool isHealthy;
  bool emergencyStopActive;
  bool manualOverride;
  unsigned long faultCount;
  unsigned long lastStateChange;
  String lastFault;
};

class RelayController {
public:
  // Constructor
  RelayController();
  
  // Initialization
  bool init();
  
  // Relay control
  bool setRelayState(RelayState state);
  bool setRelayOn();
  bool setRelayOff();
  RelayState getRelayState();
  RelayStatus getRelayStatus();
  
  // Emergency functions
  void emergencyStop();
  bool resetEmergencyStop();
  bool isEmergencyStopActive();
  
  // Safety and monitoring
  bool isRelayHealthy();
  void enableManualOverride(bool enable);
  bool isManualOverrideEnabled();
  void checkSafetyLimits(float current, float voltage);
  void handleEmergencyStopButton();
  
  // Status updates
  void updateStatus();
  void resetFaults();
  String getFaultHistory();

private:
  // Instance variables
  bool _initialized;
  RelayState _currentState;
  RelayStatus _status;
  bool _emergencyStopActive;
  bool _manualOverrideEnabled;
  bool _safetyLimitsEnabled;
  unsigned long _lastStateChange;
  unsigned long _lastEmergencyStopTime;
  unsigned long _faultResetTime;
  float _lastCurrent;
  float _lastVoltage;
  bool _overcurrentDetected;
  unsigned long _overcurrentStartTime;
  String _faultHistory;
  
  // Helper functions
  void _writeRelayPin(bool state);
  bool _readRelayFeedback();
  void _updateRelayStatus();
  void _logFault(const String& faultReason);
  bool _checkSafetyInterlocks();
  void _handleOvercurrent(float current);
  void _handleUndervoltage(float voltage);
  void _handleOvervoltage(float voltage);
  bool _canChangeState(RelayState newState);
  void _debounceRelay();
};

#endif // RELAY_CONTROLLER_H