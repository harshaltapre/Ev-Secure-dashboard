/*
 * ThreatProtection.cpp - Real-time Threat Protection Implementation
 * 
 * This implements an antivirus-like system for EV charging security.
 */

#include "ThreatProtection.h"
#include "RelayController.h"
#include "APIManager.h"

// Global instance
ThreatProtection threatProtection;

// Constructor
ThreatProtection::ThreatProtection() 
  : _protectionLevel(PROTECTION_HIGH),
    _protectionEnabled(true),
    _adminOverride(false),
    _chargingBlocked(false),
    _blockReason(""),
    _lastScanTime(0),
    _scanCount(0),
    _threatCount(0),
    _blockCount(0),
    _threatLevelSum(0.0f),
    _threatHistoryIndex(0),
    _threatHistoryCount(0),
    _realTimeProtection(true),
    _lastProtectionUpdate(0),
    _currentThreatLevel(0.0f),
    _immediateBlockRequired(false) {
  
  // Initialize stats
  _stats.totalScans = 0;
  _stats.threatsDetected = 0;
  _stats.threatsBlocked = 0;
  _stats.falsePositives = 0;
  _stats.averageThreatLevel = 0.0f;
  _stats.lastThreatTime = 0;
  _stats.lastThreatType = "";
  _stats.systemHealthy = true;
}

// Initialize threat protection system
bool ThreatProtection::initialize() {
  Serial.println("Initializing Threat Protection System...");
  
  // Initialize threat history
  for (int i = 0; i < MAX_THREAT_HISTORY; i++) {
    _threatHistory[i].threatDetected = false;
  }
  
  _protectionEnabled = true;
  _realTimeProtection = true;
  _lastScanTime = millis();
  
  Serial.println("Threat Protection System initialized");
  Serial.println("Protection Level: " + String(_protectionLevel));
  Serial.println("Real-time Protection: " + String(_realTimeProtection ? "ENABLED" : "DISABLED"));
  
  return true;
}

// Main threat scanning function
ThreatDetectionResult ThreatProtection::scanForThreats(const SensorData& sensorData, const MLPrediction& mlResult) {
  ThreatDetectionResult result;
  result.threatDetected = false;
  result.threatLevel = 0.0f;
  result.category = THREAT_CATEGORY_NONE;
  result.recommendedAction = ACTION_NONE;
  result.threatDescription = "";
  result.mitigationSteps = "";
  result.detectionTime = millis();
  result.isBlocked = false;
  result.blockReason = "";
  
  if (!_protectionEnabled) {
    return result;
  }
  
  _scanCount++;
  _stats.totalScans = _scanCount;
  
  // Perform comprehensive threat analysis
  result = analyzeThreat(sensorData, mlResult);
  
  // Update real-time protection
  if (result.threatDetected) {
    _currentThreatLevel = result.threatLevel;
    _threatCount++;
    _stats.threatsDetected = _threatCount;
    _stats.lastThreatTime = millis();
    _stats.lastThreatType = result.threatDescription;
    
    // Determine if immediate blocking is required
    if (_shouldBlockThreat(result)) {
      result.isBlocked = blockThreat(result);
      if (result.isBlocked) {
        _blockCount++;
        _stats.threatsBlocked = _blockCount;
      }
    }
    
    // Log the threat
    logThreat(result);
    
    // Send alert to dashboard
    if (result.recommendedAction >= ACTION_ALERT) {
      APIManager::sendAlert("THREAT_DETECTED", result.threatDescription);
    }
  }
  
  _lastScanTime = millis();
  return result;
}

// Block a detected threat
bool ThreatProtection::blockThreat(const ThreatDetectionResult& threat) {
  if (!_protectionEnabled || _adminOverride) {
    return false;
  }
  
  Serial.println("🚨 THREAT BLOCKED: " + threat.threatDescription);
  Serial.println("Block Reason: " + threat.blockReason);
  
  // Execute threat action
  _executeThreatAction(threat);
  
  // Block charging if required
  if (threat.recommendedAction >= ACTION_BLOCK) {
    _chargingBlocked = true;
    _blockReason = threat.threatDescription;
    
    // Turn off relay immediately
    RelayController::setRelayOff();
    
    Serial.println("🔒 CHARGING SESSION BLOCKED");
    Serial.println("Reason: " + threat.threatDescription);
    
    // Send emergency alert to dashboard
    APIManager::sendAlert("CHARGING_BLOCKED", threat.threatDescription);
    
    return true;
  }
  
  return false;
}

// Allow charging (admin override)
bool ThreatProtection::allowCharging() {
  if (_adminOverride) {
    _chargingBlocked = false;
    _blockReason = "";
    Serial.println("✅ CHARGING ALLOWED (Admin Override)");
    return true;
  }
  
  return false;
}

// Set protection level
void ThreatProtection::setProtectionLevel(ThreatProtectionLevel level) {
  _protectionLevel = level;
  Serial.println("Protection Level set to: " + String(level));
  
  // Adjust thresholds based on protection level
  switch (level) {
    case PROTECTION_DISABLED:
      _protectionEnabled = false;
      break;
    case PROTECTION_LOW:
      _protectionEnabled = true;
      break;
    case PROTECTION_MEDIUM:
      _protectionEnabled = true;
      break;
    case PROTECTION_HIGH:
      _protectionEnabled = true;
      break;
    case PROTECTION_MAXIMUM:
      _protectionEnabled = true;
      _realTimeProtection = true;
      break;
  }
}

// Enable/disable protection
bool ThreatProtection::enableProtection(bool enable) {
  _protectionEnabled = enable;
  Serial.println("Threat Protection " + String(enable ? "ENABLED" : "DISABLED"));
  return true;
}

// Set admin override
void ThreatProtection::setAdminOverride(bool override) {
  _adminOverride = override;
  if (override) {
    _chargingBlocked = false;
    _blockReason = "";
    Serial.println("🔓 ADMIN OVERRIDE ACTIVE");
  } else {
    Serial.println("🔒 ADMIN OVERRIDE DISABLED");
  }
}

// Comprehensive threat analysis
ThreatDetectionResult ThreatProtection::analyzeThreat(const SensorData& sensorData, const MLPrediction& mlResult) {
  ThreatDetectionResult result;
  result.threatDetected = false;
  result.threatLevel = 0.0f;
  result.category = THREAT_CATEGORY_NONE;
  result.recommendedAction = ACTION_NONE;
  result.detectionTime = millis();
  
  // Check electrical threats
  ThreatDetectionResult electricalThreat = _detectElectricalThreats(sensorData);
  if (electricalThreat.threatDetected && electricalThreat.threatLevel > result.threatLevel) {
    result = electricalThreat;
  }
  
  // Check protocol threats
  ThreatDetectionResult protocolThreat = _detectProtocolThreats(sensorData, mlResult);
  if (protocolThreat.threatDetected && protocolThreat.threatLevel > result.threatLevel) {
    result = protocolThreat;
  }
  
  // Check power threats
  ThreatDetectionResult powerThreat = _detectPowerThreats(sensorData);
  if (powerThreat.threatDetected && powerThreat.threatLevel > result.threatLevel) {
    result = powerThreat;
  }
  
  // Check security threats
  ThreatDetectionResult securityThreat = _detectSecurityThreats(sensorData, mlResult);
  if (securityThreat.threatDetected && securityThreat.threatLevel > result.threatLevel) {
    result = securityThreat;
  }
  
  // Determine recommended action
  if (result.threatDetected) {
    result.recommendedAction = _determineThreatAction(result);
    result.threatDescription = _generateThreatDescription(result);
    result.mitigationSteps = _generateMitigationSteps(result);
  }
  
  return result;
}

// Detect electrical threats
ThreatDetectionResult ThreatProtection::_detectElectricalThreats(const SensorData& sensorData) {
  ThreatDetectionResult result;
  result.threatDetected = false;
  result.threatLevel = 0.0f;
  result.category = THREAT_CATEGORY_ELECTRICAL;
  
  // Overcurrent detection
  if (sensorData.current > MAX_CURRENT * 0.9) {
    result.threatDetected = true;
    result.threatLevel = 0.8f;
    result.threatDescription = "CRITICAL: Overcurrent detected (" + String(sensorData.current, 2) + "A)";
    result.blockReason = "Overcurrent protection triggered";
  }
  
  // Voltage anomaly detection
  if (sensorData.voltage < 200.0f || sensorData.voltage > 450.0f) {
    result.threatDetected = true;
    result.threatLevel = 0.9f;
    result.threatDescription = "CRITICAL: Voltage anomaly (" + String(sensorData.voltage, 1) + "V)";
    result.blockReason = "Voltage out of safe range";
  }
  
  // Frequency deviation
  if (sensorData.frequency < 45.0f || sensorData.frequency > 55.0f) {
    result.threatDetected = true;
    result.threatLevel = 0.6f;
    result.threatDescription = "WARNING: Frequency deviation (" + String(sensorData.frequency, 1) + "Hz)";
    result.blockReason = "Frequency out of normal range";
  }
  
  return result;
}

// Detect protocol threats (OCPP attacks)
ThreatDetectionResult ThreatProtection::_detectProtocolThreats(const SensorData& sensorData, const MLPrediction& mlResult) {
  ThreatDetectionResult result;
  result.threatDetected = false;
  result.threatLevel = 0.0f;
  result.category = THREAT_CATEGORY_PROTOCOL;
  
  // High ML prediction indicates potential protocol attack
  if (mlResult.prediction > 0.8f) {
    result.threatDetected = true;
    result.threatLevel = mlResult.prediction;
    result.threatDescription = "SECURITY: Potential OCPP protocol attack detected";
    result.blockReason = "ML model detected suspicious charging pattern";
  }
  
  // Rapid parameter changes (potential attack)
  static float lastCurrent = 0.0f;
  static float lastVoltage = 0.0f;
  
  if (lastCurrent > 0 && lastVoltage > 0) {
    float currentChange = abs(sensorData.current - lastCurrent) / lastCurrent;
    float voltageChange = abs(sensorData.voltage - lastVoltage) / lastVoltage;
    
    if (currentChange > 0.5f || voltageChange > 0.3f) {
      result.threatDetected = true;
      result.threatLevel = 0.7f;
      result.threatDescription = "SECURITY: Rapid parameter changes detected";
      result.blockReason = "Suspicious rapid changes in electrical parameters";
    }
  }
  
  lastCurrent = sensorData.current;
  lastVoltage = sensorData.voltage;
  
  return result;
}

// Detect power quality threats
ThreatDetectionResult ThreatProtection::_detectPowerThreats(const SensorData& sensorData) {
  ThreatDetectionResult result;
  result.threatDetected = false;
  result.threatLevel = 0.0f;
  result.category = THREAT_CATEGORY_POWER;
  
  // Power factor anomaly
  float powerFactor = sensorData.power / (sensorData.voltage * sensorData.current);
  if (powerFactor < 0.7f && sensorData.current > 1.0f) {
    result.threatDetected = true;
    result.threatLevel = 0.5f;
    result.threatDescription = "WARNING: Poor power factor (" + String(powerFactor, 2) + ")";
    result.blockReason = "Power factor below acceptable threshold";
  }
  
  // Power mismatch
  float expectedPower = sensorData.current * sensorData.voltage;
  float powerDifference = abs(sensorData.power - expectedPower);
  if (powerDifference > expectedPower * 0.15f && expectedPower > 100.0f) {
    result.threatDetected = true;
    result.threatLevel = 0.6f;
    result.threatDescription = "WARNING: Power measurement mismatch";
    result.blockReason = "Calculated vs measured power difference too high";
  }
  
  return result;
}

// Detect general security threats
ThreatDetectionResult ThreatProtection::_detectSecurityThreats(const SensorData& sensorData, const MLPrediction& mlResult) {
  ThreatDetectionResult result;
  result.threatDetected = false;
  result.threatLevel = 0.0f;
  result.category = THREAT_CATEGORY_SECURITY;
  
  // High confidence ML prediction
  if (mlResult.confidence > 0.9f && mlResult.prediction > 0.6f) {
    result.threatDetected = true;
    result.threatLevel = mlResult.prediction;
    result.threatDescription = "SECURITY: High-confidence threat detected by ML model";
    result.blockReason = "Machine learning model detected security threat";
  }
  
  return result;
}

// Determine threat action
ThreatAction ThreatProtection::_determineThreatAction(const ThreatDetectionResult& threat) {
  if (threat.threatLevel >= 0.9f) {
    return ACTION_EMERGENCY;
  } else if (threat.threatLevel >= 0.7f) {
    return ACTION_BLOCK;
  } else if (threat.threatLevel >= 0.5f) {
    return ACTION_ALERT;
  } else {
    return ACTION_WARN;
  }
}

// Check if threat should be blocked
bool ThreatProtection::_shouldBlockThreat(const ThreatDetectionResult& threat) {
  if (_adminOverride) {
    return false;
  }
  
  switch (_protectionLevel) {
    case PROTECTION_DISABLED:
      return false;
    case PROTECTION_LOW:
      return threat.threatLevel >= 0.9f;
    case PROTECTION_MEDIUM:
      return threat.threatLevel >= 0.7f;
    case PROTECTION_HIGH:
      return threat.threatLevel >= 0.6f;
    case PROTECTION_MAXIMUM:
      return threat.threatLevel >= 0.4f;
    default:
      return threat.threatLevel >= 0.7f;
  }
}

// Generate threat description
String ThreatProtection::_generateThreatDescription(const ThreatDetectionResult& threat) {
  String description = "Threat Level: " + String(threat.threatLevel * 100, 1) + "%";
  description += " | Category: ";
  
  switch (threat.category) {
    case THREAT_CATEGORY_ELECTRICAL:
      description += "Electrical";
      break;
    case THREAT_CATEGORY_PROTOCOL:
      description += "Protocol";
      break;
    case THREAT_CATEGORY_POWER:
      description += "Power Quality";
      break;
    case THREAT_CATEGORY_SECURITY:
      description += "Security";
      break;
    default:
      description += "Unknown";
      break;
  }
  
  return description;
}

// Generate mitigation steps
String ThreatProtection::_generateMitigationSteps(const ThreatDetectionResult& threat) {
  String steps = "Recommended Actions: ";
  
  switch (threat.recommendedAction) {
    case ACTION_WARN:
      steps += "Monitor closely";
      break;
    case ACTION_ALERT:
      steps += "Send alert to admin";
      break;
    case ACTION_BLOCK:
      steps += "Block charging session";
      break;
    case ACTION_EMERGENCY:
      steps += "Emergency stop + lockdown";
      break;
    default:
      steps += "No action required";
      break;
  }
  
  return steps;
}

// Execute threat action
void ThreatProtection::_executeThreatAction(const ThreatDetectionResult& threat) {
  switch (threat.recommendedAction) {
    case ACTION_EMERGENCY:
      RelayController::emergencyStop();
      Serial.println("🚨 EMERGENCY STOP ACTIVATED");
      break;
    case ACTION_BLOCK:
      RelayController::setRelayOff();
      Serial.println("🔒 CHARGING BLOCKED");
      break;
    case ACTION_ALERT:
      Serial.println("⚠️ ALERT SENT TO DASHBOARD");
      break;
    case ACTION_WARN:
      Serial.println("⚠️ WARNING LOGGED");
      break;
  }
}

// Log threat to history
void ThreatProtection::logThreat(const ThreatDetectionResult& threat) {
  _threatHistory[_threatHistoryIndex] = threat;
  _threatHistoryIndex = (_threatHistoryIndex + 1) % MAX_THREAT_HISTORY;
  if (_threatHistoryCount < MAX_THREAT_HISTORY) {
    _threatHistoryCount++;
  }
  
  _updateProtectionStats(threat);
}

// Update protection statistics
void ThreatProtection::_updateProtectionStats(const ThreatDetectionResult& threat) {
  _threatLevelSum += threat.threatLevel;
  _stats.averageThreatLevel = _threatLevelSum / _threatCount;
}

// Get threat report
String ThreatProtection::getThreatReport() const {
  String report = "=== THREAT PROTECTION REPORT ===\n";
  report += "Protection Level: " + String(_protectionLevel) + "\n";
  report += "Protection Enabled: " + String(_protectionEnabled ? "YES" : "NO") + "\n";
  report += "Admin Override: " + String(_adminOverride ? "ACTIVE" : "INACTIVE") + "\n";
  report += "Charging Blocked: " + String(_chargingBlocked ? "YES" : "NO") + "\n";
  report += "Total Scans: " + String(_stats.totalScans) + "\n";
  report += "Threats Detected: " + String(_stats.threatsDetected) + "\n";
  report += "Threats Blocked: " + String(_stats.threatsBlocked) + "\n";
  report += "Average Threat Level: " + String(_stats.averageThreatLevel * 100, 1) + "%\n";
  
  if (_chargingBlocked) {
    report += "Block Reason: " + _blockReason + "\n";
  }
  
  return report;
}

// Get protection statistics
ThreatProtectionStats ThreatProtection::getProtectionStats() const {
  return _stats;
}

// Check if charging is allowed
bool ThreatProtection::isChargingAllowed() const {
  return !_chargingBlocked || _adminOverride;
}

// Get block reason
String ThreatProtection::getBlockReason() const {
  return _blockReason;
}

// Get dashboard data
String ThreatProtection::getDashboardData() const {
  String data = "{";
  data += "\"protectionEnabled\":" + String(_protectionEnabled ? "true" : "false") + ",";
  data += "\"protectionLevel\":" + String(_protectionLevel) + ",";
  data += "\"adminOverride\":" + String(_adminOverride ? "true" : "false") + ",";
  data += "\"chargingBlocked\":" + String(_chargingBlocked ? "true" : "false") + ",";
  data += "\"currentThreatLevel\":" + String(_currentThreatLevel, 3) + ",";
  data += "\"totalScans\":" + String(_stats.totalScans) + ",";
  data += "\"threatsDetected\":" + String(_stats.threatsDetected) + ",";
  data += "\"threatsBlocked\":" + String(_stats.threatsBlocked) + ",";
  data += "\"averageThreatLevel\":" + String(_stats.averageThreatLevel, 3) + ",";
  data += "\"blockReason\":\"" + _blockReason + "\"";
  data += "}";
  
  return data;
}

// Process admin command
bool ThreatProtection::processAdminCommand(const String& command) {
  if (command == "ENABLE_PROTECTION") {
    enableProtection(true);
    return true;
  } else if (command == "DISABLE_PROTECTION") {
    enableProtection(false);
    return true;
  } else if (command == "ALLOW_CHARGING") {
    allowCharging();
    return true;
  } else if (command == "BLOCK_CHARGING") {
    _chargingBlocked = true;
    _blockReason = "Admin manual block";
    RelayController::setRelayOff();
    return true;
  } else if (command == "ADMIN_OVERRIDE_ON") {
    setAdminOverride(true);
    return true;
  } else if (command == "ADMIN_OVERRIDE_OFF") {
    setAdminOverride(false);
    return true;
  }
  
  return false;
}

// Get threat history
String ThreatProtection::getThreatHistory() const {
  String history = "=== THREAT HISTORY ===\n";
  
  int startIndex = (_threatHistoryCount < MAX_THREAT_HISTORY) ? 0 : _threatHistoryIndex;
  int count = min(_threatHistoryCount, MAX_THREAT_HISTORY);
  
  for (int i = 0; i < count; i++) {
    int index = (startIndex + i) % MAX_THREAT_HISTORY;
    const ThreatDetectionResult& threat = _threatHistory[index];
    
    if (threat.threatDetected) {
      history += String(i + 1) + ". " + threat.threatDescription + "\n";
      history += "   Time: " + String(threat.detectionTime) + "\n";
      history += "   Level: " + String(threat.threatLevel * 100, 1) + "%\n";
      history += "   Blocked: " + String(threat.isBlocked ? "YES" : "NO") + "\n\n";
    }
  }
  
  return history;
}

// Clear threat history
void ThreatProtection::clearThreatHistory() {
  for (int i = 0; i < MAX_THREAT_HISTORY; i++) {
    _threatHistory[i].threatDetected = false;
  }
  _threatHistoryIndex = 0;
  _threatHistoryCount = 0;
  
  Serial.println("Threat history cleared");
}
