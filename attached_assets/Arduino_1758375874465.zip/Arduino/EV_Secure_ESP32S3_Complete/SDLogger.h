/*
 * SDLogger.h - SD Card Logging Library
 * 
 * This library handles data logging to SD card for the EV-Secure system.
 * It provides structured logging of sensor data, ML predictions, system events,
 * and alerts for offline analysis and debugging.
 * 
 * Features:
 * - Structured CSV logging
 * - Automatic file rotation
 * - Data compression and archiving
 * - Error handling and recovery
 * - Log file management
 * - Real-time data logging
 * 
 * Log Files:
 * - sensor_data.csv: Continuous sensor readings
 * - ml_predictions.csv: ML model predictions and results
 * - system_events.csv: System state changes and events
 * - alerts.csv: Threat detections and alerts
 * - error_log.txt: System errors and debugging info
 * 
 * Usage:
 * 1. Initialize with SDLogger::init()
 * 2. Log data with SDLogger::logSensorData(), logMLPrediction(), etc.
 * 3. Manage files with SDLogger::rotateLogs(), cleanupOldLogs()
 */

#ifndef SD_LOGGER_H
#define SD_LOGGER_H

#include "EV_Secure_Config.h"
#include <SD.h>
#include <SPI.h>

// Log file names
#define SENSOR_LOG_FILE "sensor_data.csv"
#define ML_LOG_FILE "ml_predictions.csv"
#define EVENT_LOG_FILE "system_events.csv"
#define ALERT_LOG_FILE "alerts.csv"
#define ERROR_LOG_FILE "error_log.txt"

// Log file limits
#define MAX_LOG_FILE_SIZE 1048576  // 1MB
#define MAX_LOG_FILES 10
#define LOG_BUFFER_SIZE 1024

// Log entry types
enum LogEntryType {
  LOG_SENSOR_DATA,
  LOG_ML_PREDICTION,
  LOG_SYSTEM_EVENT,
  LOG_ALERT,
  LOG_ERROR
};

// Log entry structure
struct LogEntry {
  LogEntryType type;
  unsigned long timestamp;
  String data;
  bool isCritical;
};

class SDLogger {
public:
  static bool init();
  static void logSensorData(const SensorData& sensorData);
  static void logMLPrediction(const MLPrediction& mlResult);
  static void logSystemEvent(const String& event);
  static void logSystemState(SystemState state);
  static void logThreatDetection(const MLPrediction& mlResult);
  static void logAlert(const String& alertType, const String& details);
  static void logError(const String& error);
  static void logSystemEvent(const String& event, bool isCritical);
  
  // File management
  static void rotateLogs();
  static void cleanupOldLogs();
  static void uploadPendingLogs();
  static bool isSDCardHealthy();
  static size_t getFreeSpace();
  static void formatSDCard();
  
  // Configuration
  static void setLogLevel(int level);
  static void enableLogging(bool enable);
  static void setLogInterval(unsigned long interval);
  
private:
  static bool _initialized;
  static bool _loggingEnabled;
  static int _logLevel;
  static unsigned long _lastLogTime;
  static unsigned long _logInterval;
  static String _logBuffer;
  
  // File handles
  static File _sensorLogFile;
  static File _mlLogFile;
  static File _eventLogFile;
  static File _alertLogFile;
  static File _errorLogFile;
  
  // Helper methods
  static bool _writeToFile(File& file, const String& data);
  static String _formatTimestamp(unsigned long timestamp);
  static String _formatSensorData(const SensorData& sensorData);
  static String _formatMLPrediction(const MLPrediction& mlResult);
  static String _formatSystemEvent(const String& event, SystemState state);
  static String _formatAlert(const String& alertType, const String& details);
  static void _flushBuffer();
  static bool _checkFileSize(File& file);
  static void _createLogFiles();
  static void _writeCSVHeader(File& file, const String& headers);
};

#endif // SD_LOGGER_H