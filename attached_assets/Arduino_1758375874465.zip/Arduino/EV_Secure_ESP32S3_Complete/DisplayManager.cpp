/*
 * DisplayManager.cpp - Display Management Implementation
 * 
 * This file implements the DisplayManager class for handling TFT display operations
 * in the EV-Secure system.
 */

#include "DisplayManager.h"

// Constructor
DisplayManager::DisplayManager(int cs, int dc, int rst) 
  : _tft(cs, dc, rst), _initialized(false), _currentState(DISPLAY_STARTUP), _lastUpdate(0) {
}

// Initialize display
bool DisplayManager::init() {
  if (_initialized) {
    return true;
  }
  
  Serial.println("Initializing TFT Display...");
  
  _tft.initR(INITR_BLACKTAB);
  _tft.setRotation(1);
  _tft.fillScreen(COLOR_BLACK);
  
  _initialized = true;
  _currentState = DISPLAY_NORMAL;
  _lastUpdate = millis();
  
  Serial.println("TFT Display initialized successfully");
  return true;
}

// Update display with sensor data and ML results
void DisplayManager::updateDisplay(const SensorData& sensorData, const MLPrediction& mlResult) {
  if (!_initialized) {
    return;
  }
  
  unsigned long now = millis();
  if (now - _lastUpdate < DISPLAY_UPDATE_INTERVAL) {
    return; // Too soon to update
  }
  
  _lastUpdate = now;
  
  // Clear screen
  clearScreen();
  
  // Draw header
  _drawHeader();
  
  // Draw sensor data
  _drawSensorData(sensorData);
  
  // Draw ML status
  _drawMLStatus(mlResult);
  
  // Draw status bar
  _drawStatusBar();
}

// Clear screen
void DisplayManager::clearScreen() {
  if (_initialized) {
    _tft.fillScreen(COLOR_BLACK);
  }
}

// Draw header
void DisplayManager::_drawHeader() {
  _tft.setTextColor(COLOR_WHITE);
  _tft.setTextSize(1);
  _tft.setCursor(5, 5);
  _tft.print("EV-Secure Monitor");
  
  // Draw status indicator
  uint16_t statusColor = COLOR_GREEN;
  _tft.fillCircle(TFT_WIDTH - 10, 10, 5, statusColor);
}

// Draw sensor data
void DisplayManager::_drawSensorData(const SensorData& data) {
  int y = 25;
  
  _drawCenteredText(y, "Voltage: " + String(data.voltage, 1) + "V", COLOR_WHITE, 1);
  y += 15;
  
  _drawCenteredText(y, "Current: " + String(data.current, 2) + "A", COLOR_WHITE, 1);
  y += 15;
  
  _drawCenteredText(y, "Power: " + String(data.power, 1) + "W", COLOR_WHITE, 1);
  y += 15;
  
  _drawCenteredText(y, "Freq: " + String(data.frequency, 1) + "Hz", COLOR_WHITE, 1);
}

// Draw ML status
void DisplayManager::_drawMLStatus(const MLPrediction& mlResult) {
  int y = 90;
  
  _drawCenteredText(y, "Threat Level:", COLOR_WHITE, 1);
  y += 15;
  
  String threatText = String(mlResult.prediction * 100, 1) + "%";
  uint16_t threatColor = COLOR_GREEN;
  
  if (mlResult.prediction > 0.7) {
    threatColor = COLOR_RED;
  } else if (mlResult.prediction > 0.4) {
    threatColor = COLOR_YELLOW;
  }
  
  _drawCenteredText(y, threatText, threatColor, 2);
}

// Draw status bar
void DisplayManager::_drawStatusBar() {
  String timestamp = String(millis() / 1000) + "s";
  _drawCenteredText(TFT_HEIGHT - 15, timestamp, COLOR_GRAY, 1);
}

// Draw centered text helper
void DisplayManager::_drawCenteredText(int y, const String& text, uint16_t color, uint8_t size) {
  _tft.setTextColor(color);
  _tft.setTextSize(size);
  int x = (TFT_WIDTH - text.length() * 6 * size) / 2;
  _tft.setCursor(x, y);
  _tft.print(text);
}

// Show startup screen
void DisplayManager::showStartupScreen() {
  if (!_initialized) return;
  
  clearScreen();
  _drawCenteredText(TFT_HEIGHT / 2 - 20, "EV-Secure", COLOR_WHITE, 2);
  _drawCenteredText(TFT_HEIGHT / 2, "Initializing...", COLOR_YELLOW, 1);
}

// Show lockdown screen
void DisplayManager::showLockdownScreen() {
  if (!_initialized) return;
  
  clearScreen();
  _tft.fillScreen(COLOR_RED);
  _drawCenteredText(TFT_HEIGHT / 2 - 20, "LOCKDOWN", COLOR_WHITE, 2);
  _drawCenteredText(TFT_HEIGHT / 2, "System Secured", COLOR_WHITE, 1);
}

// Set brightness (not supported by ST7735, but kept for compatibility)
void DisplayManager::setBrightness(uint8_t brightness) {
  // ST7735 doesn't support brightness control
  // This is kept for compatibility with other display types
}

// Static utility functions
void DisplayManager::showErrorScreen(const String& error) {
  // This would need a global display instance to work properly
  // For now, just print to serial
  Serial.println("Display Error: " + error);
}

void DisplayManager::showAlertScreen(const String& alert) {
  // This would need a global display instance to work properly
  // For now, just print to serial
  Serial.println("Display Alert: " + alert);
}

// Draw progress bar helper
void DisplayManager::_drawProgressBar(int x, int y, int width, int height, float progress, uint16_t color) {
  _tft.fillRect(x, y, width, height, COLOR_DARK_GRAY);
  int progressWidth = (int)(width * progress);
  if (progressWidth > 0) {
    _tft.fillRect(x, y, progressWidth, height, color);
  }
  _tft.drawRect(x, y, width, height, COLOR_WHITE);
}
