/*
 * APIManager.h - API Communication Library
 * 
 * This library handles communication with the dashboard API for the EV-Secure system.
 * It provides secure data transmission, command reception, and alert management.
 */

#ifndef API_MANAGER_H
#define API_MANAGER_H

#include "EV_Secure_Config.h"
#include "SecurityMetrics.h"
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>

// API endpoints
#define API_DATA_ENDPOINT "/api/data"
#define API_COMMANDS_ENDPOINT "/api/commands"
#define API_ALERTS_ENDPOINT "/api/alerts"
#define API_STATUS_ENDPOINT "/api/status"

// HTTP status codes
#define HTTP_OK 200
#define HTTP_CREATED 201
#define HTTP_BAD_REQUEST 400
#define HTTP_UNAUTHORIZED 401
#define HTTP_FORBIDDEN 403
#define HTTP_NOT_FOUND 404
#define HTTP_INTERNAL_ERROR 500

// Rate limiting
#define MAX_REQUESTS_PER_MINUTE 30
#define REQUEST_WINDOW_MS 60000

// Response structure
struct APIResponse {
  bool success;
  int statusCode;
  String data;
  String error;
};

// Command structure
enum CommandType {
  COMMAND_NONE,
  COMMAND_START_CHARGING,
  COMMAND_STOP_CHARGING,
  COMMAND_EMERGENCY_STOP,
  COMMAND_RESET_SYSTEM,
  COMMAND_UPDATE_CONFIG,
  COMMAND_THREAT_REPORT,
  COMMAND_THREAT_HISTORY
};

struct Command {
  CommandType type;
  String data;
  unsigned long timestamp;
  bool processed;
};

class APIManager {
public:
  // Constructor
  APIManager();
  
  // Initialization
  bool init();
  
  // Data transmission
  bool sendData(const SensorData& sensorData, const MLPrediction& mlData);
  bool sendAnalytics(const SecurityMetrics& metrics);
  bool sendAlert(const String& alertType, const String& message);
  
  // Command handling
  Command getCommand();
  bool checkConnection();
  
  // Configuration
  void setServerURL(const String& serverURL) { _serverURL = serverURL; }
  void enableSSL(bool enable) { _useSSL = enable; }
  void setAPIKey(const String& apiKey) { _apiKey = apiKey; }
  void setRateLimit(int requestsPerMinute) { _maxRequestsPerMinute = requestsPerMinute; }
  
  // Status and error handling
  bool isConnected();
  int getRequestCount();
  String getLastError();
  void resetErrorCount();

private:
  // Instance variables
  bool _initialized;
  String _apiKey;
  String _serverURL;
  bool _useSSL;
  unsigned long _requestCount;
  unsigned long _lastRequestTime;
  unsigned long _requestWindowStart;
  String _lastError;
  HTTPClient _httpClient;
  WiFiClientSecure _secureClient;
  int _maxRequestsPerMinute;
  
  // Helper functions
  String _buildURL(const String& endpoint);
  String _buildHeaders();
  bool _checkRateLimit();
  void _updateRateLimit();
  String _formatSensorData(const SensorData& sensorData);
  String _formatMLPrediction(const MLPrediction& mlResult);
  String _formatSystemState(SystemState state);
  CommandType _parseCommandType(const String& type);
  void _logError(const String& error);
  bool _retryRequest(const String& endpoint, const String& method, const String& data, APIResponse& response);
};

#endif // API_MANAGER_H