/*
 * APIManager.cpp - API Communication Implementation
 * 
 * This file implements the APIManager class for handling API communication
 * in the EV-Secure system.
 */

#include "APIManager.h"

// Constructor
APIManager::APIManager() 
  : _initialized(false), _useSSL(true), _requestCount(0), _lastRequestTime(0),
    _requestWindowStart(0), _maxRequestsPerMinute(MAX_REQUESTS_PER_MINUTE) {
  _apiKey = API_KEY;
  _serverURL = DASHBOARD_URL;
}

// Initialize API manager
bool APIManager::init() {
  if (_initialized) {
    return true;
  }
  
  Serial.println("Initializing API Manager...");
  
  // Initialize HTTP client
  if (_useSSL) {
    _secureClient.setInsecure(); // For development - use certificates in production
    _httpClient.begin(_secureClient, _serverURL + API_DATA_ENDPOINT);
  } else {
    _httpClient.begin(_serverURL + API_DATA_ENDPOINT);
  }
  
  _initialized = true;
  Serial.println("API Manager initialized successfully");
  return true;
}

// Send sensor data and ML prediction
bool APIManager::sendData(const SensorData& sensorData, const MLPrediction& mlData) {
  if (!_initialized) {
    return false;
  }
  
  // Check rate limit
  if (!_checkRateLimit()) {
    _logError("Rate limit exceeded");
    return false;
  }
  
  // Build JSON payload
  String jsonData = _formatSensorData(sensorData);
  jsonData += ",";
  jsonData += _formatMLPrediction(mlData);
  
  // Send data
  _httpClient.addHeader("Content-Type", "application/json");
  _httpClient.addHeader("X-API-Key", _apiKey);
  
  int httpResponseCode = _httpClient.POST(jsonData);
  
  if (httpResponseCode > 0) {
    String response = _httpClient.getString();
    Serial.println("Data sent successfully. Response: " + response);
    _updateRateLimit();
    return true;
  } else {
    _logError("HTTP Error: " + String(httpResponseCode));
    return false;
  }
}

// Send analytics data
bool APIManager::sendAnalytics(const SecurityMetrics& metrics) {
  if (!_initialized) {
    return false;
  }
  
  // Build analytics JSON
  String jsonData = "{";
  jsonData += "\"totalEvents\":" + String(metrics.totalEvents) + ",";
  jsonData += "\"threatEvents\":" + String(metrics.threatEvents) + ",";
  jsonData += "\"averageThreatLevel\":" + String(metrics.averageThreatLevel, 2) + ",";
  jsonData += "\"maxThreatLevel\":" + String(metrics.maxThreatLevel, 2) + ",";
  jsonData += "\"uptime\":" + String(metrics.uptime);
  jsonData += "}";
  
  // Send analytics
  _httpClient.addHeader("Content-Type", "application/json");
  _httpClient.addHeader("X-API-Key", _apiKey);
  
  int httpResponseCode = _httpClient.POST(jsonData);
  
  if (httpResponseCode > 0) {
    _updateRateLimit();
    return true;
  } else {
    _logError("Analytics send failed: " + String(httpResponseCode));
    return false;
  }
}

// Send alert
bool APIManager::sendAlert(const String& alertType, const String& message) {
  if (!_initialized) {
    return false;
  }
  
  // Build alert JSON
  String jsonData = "{";
  jsonData += "\"alertType\":\"" + alertType + "\",";
  jsonData += "\"message\":\"" + message + "\",";
  jsonData += "\"timestamp\":" + String(millis());
  jsonData += "}";
  
  // Send alert
  _httpClient.addHeader("Content-Type", "application/json");
  _httpClient.addHeader("X-API-Key", _apiKey);
  
  int httpResponseCode = _httpClient.POST(jsonData);
  
  if (httpResponseCode > 0) {
    _updateRateLimit();
    return true;
  } else {
    _logError("Alert send failed: " + String(httpResponseCode));
    return false;
  }
}

// Get command from dashboard
Command APIManager::getCommand() {
  Command cmd;
  cmd.type = COMMAND_NONE;
  cmd.processed = false;
  
  if (!_initialized) {
    return cmd;
  }
  
  // Check for commands endpoint
  _httpClient.begin(_serverURL + API_COMMANDS_ENDPOINT);
  _httpClient.addHeader("X-API-Key", _apiKey);
  
  int httpResponseCode = _httpClient.GET();
  
  if (httpResponseCode > 0) {
    String response = _httpClient.getString();
    if (response.length() > 0) {
      // Parse command from response
      cmd.type = _parseCommandType(response);
      cmd.data = response;
      cmd.timestamp = millis();
    }
  }
  
  return cmd;
}

// Check connection status
bool APIManager::checkConnection() {
  if (!_initialized) {
    return false;
  }
  
  _httpClient.begin(_serverURL + API_STATUS_ENDPOINT);
  _httpClient.addHeader("X-API-Key", _apiKey);
  
  int httpResponseCode = _httpClient.GET();
  
  return (httpResponseCode > 0);
}

// Status and error handling
bool APIManager::isConnected() {
  return checkConnection();
}

int APIManager::getRequestCount() {
  return _requestCount;
}

String APIManager::getLastError() {
  return _lastError;
}

void APIManager::resetErrorCount() {
  _lastError = "";
  _requestCount = 0;
}

// Private helper functions
String APIManager::_buildURL(const String& endpoint) {
  return _serverURL + endpoint;
}

String APIManager::_buildHeaders() {
  String headers = "Content-Type: application/json\r\n";
  headers += "X-API-Key: " + _apiKey + "\r\n";
  return headers;
}

bool APIManager::_checkRateLimit() {
  unsigned long now = millis();
  
  // Reset window if needed
  if (now - _requestWindowStart > REQUEST_WINDOW_MS) {
    _requestWindowStart = now;
    _requestCount = 0;
  }
  
  return _requestCount < _maxRequestsPerMinute;
}

void APIManager::_updateRateLimit() {
  _requestCount++;
  _lastRequestTime = millis();
}

String APIManager::_formatSensorData(const SensorData& sensorData) {
  String json = "\"sensorData\":{";
  json += "\"current\":" + String(sensorData.current, 3) + ",";
  json += "\"voltage\":" + String(sensorData.voltage, 1) + ",";
  json += "\"power\":" + String(sensorData.power, 1) + ",";
  json += "\"frequency\":" + String(sensorData.frequency, 1) + ",";
  json += "\"temperature\":" + String(sensorData.temperature, 1) + ",";
  json += "\"timestamp\":" + String(sensorData.timestamp);
  json += "}";
  return json;
}

String APIManager::_formatMLPrediction(const MLPrediction& mlResult) {
  String json = "\"mlPrediction\":{";
  json += "\"prediction\":" + String(mlResult.prediction, 4) + ",";
  json += "\"confidence\":" + String(mlResult.confidence, 4) + ",";
  json += "\"timestamp\":" + String(mlResult.timestamp);
  json += "}";
  return json;
}

String APIManager::_formatSystemState(SystemState state) {
  String stateStr = "";
  switch (state) {
    case STATE_IDLE: stateStr = "IDLE"; break;
    case STATE_READY: stateStr = "READY"; break;
    case STATE_CHARGING: stateStr = "CHARGING"; break;
    case STATE_SUSPICIOUS: stateStr = "SUSPICIOUS"; break;
    case STATE_LOCKDOWN: stateStr = "LOCKDOWN"; break;
    default: stateStr = "UNKNOWN"; break;
  }
  return stateStr;
}

CommandType APIManager::_parseCommandType(const String& type) {
  if (type.indexOf("START_CHARGING") >= 0) return COMMAND_START_CHARGING;
  if (type.indexOf("STOP_CHARGING") >= 0) return COMMAND_STOP_CHARGING;
  if (type.indexOf("EMERGENCY_STOP") >= 0) return COMMAND_EMERGENCY_STOP;
  if (type.indexOf("RESET_SYSTEM") >= 0) return COMMAND_RESET_SYSTEM;
  if (type.indexOf("THREAT_REPORT") >= 0) return COMMAND_THREAT_REPORT;
  if (type.indexOf("THREAT_HISTORY") >= 0) return COMMAND_THREAT_HISTORY;
  return COMMAND_NONE;
}

void APIManager::_logError(const String& error) {
  _lastError = error;
  Serial.println("API Error: " + error);
}

bool APIManager::_retryRequest(const String& endpoint, const String& method, const String& data, APIResponse& response) {
  // Simple retry logic - in production, implement exponential backoff
  for (int i = 0; i < 3; i++) {
    delay(1000 * (i + 1)); // Wait 1s, 2s, 3s
    
    if (method == "POST") {
      int httpResponseCode = _httpClient.POST(data);
      if (httpResponseCode > 0) {
        response.success = true;
        response.statusCode = httpResponseCode;
        response.data = _httpClient.getString();
        return true;
      }
    } else if (method == "GET") {
      int httpResponseCode = _httpClient.GET();
      if (httpResponseCode > 0) {
        response.success = true;
        response.statusCode = httpResponseCode;
        response.data = _httpClient.getString();
        return true;
      }
    }
  }
  
  response.success = false;
  response.statusCode = -1;
  response.error = "Max retries exceeded";
  return false;
}