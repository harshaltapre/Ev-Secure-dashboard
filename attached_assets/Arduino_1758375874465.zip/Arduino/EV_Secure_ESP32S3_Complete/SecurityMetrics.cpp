/*
 * SecurityMetrics.cpp - Security Metrics Implementation
 * 
 * This file implements the SecurityMetrics class for tracking security metrics
 * and threat detection data in the EV-Secure system.
 */

#include "SecurityMetrics.h"

// Constructor
SecurityMetrics::SecurityMetrics() : 
    currentVariation(0.0f),
    voltageVariation(0.0f),
    frequencyDeviation(0.0f),
    powerFactor(1.0f),
    temperatureAnomaly(0.0f),
    networkAnomalyDetected(false),
    totalEvents(0),
    threatEvents(0),
    averageThreatLevel(0.0f),
    maxThreatLevel(0.0f),
    uptime(0),
    updateCount(0),
    threatLevelSum(0.0f),
    lastUpdateTime(0),
    nominalCurrent(15.0f),
    nominalVoltage(230.0f),
    nominalFrequency(50.0f),
    normalTemperature(25.0f),
    systemStartTime(millis())
{
    resetStatistics();
}

// Methods for updating metrics
void SecurityMetrics::updateElectricalMetrics(float current, float voltage, float frequency) {
    // Calculate variations from nominal values
    currentVariation = abs(current - nominalCurrent) / nominalCurrent * 100.0f;
    voltageVariation = abs(voltage - nominalVoltage) / nominalVoltage * 100.0f;
    frequencyDeviation = abs(frequency - nominalFrequency);
    
    // Update power factor (simplified calculation)
    powerFactor = (current > 0.1f) ? min(1.0f, (voltage * current) / (voltage * current)) : 1.0f;
    
    updateTimestamp();
}

void SecurityMetrics::updateTemperature(float temp) {
    temperatureAnomaly = max(0.0f, temp - normalTemperature);
    updateTimestamp();
}

void SecurityMetrics::updateNetworkStatus(bool anomalyDetected) {
    networkAnomalyDetected = anomalyDetected;
    updateTimestamp();
}

void SecurityMetrics::updateThreatLevel(float newThreatLevel) {
    // Clamp threat level to valid range
    newThreatLevel = max(0.0f, min(MAX_THREAT_LEVEL, newThreatLevel));
    
    // Update statistics
    updateStatistics(newThreatLevel);
    
    // Add to history
    threatHistory.push(newThreatLevel);
    
    // Update max threat level
    if (newThreatLevel > maxThreatLevel) {
        maxThreatLevel = newThreatLevel;
    }
    
    updateTimestamp();
}

// Analysis methods
float SecurityMetrics::calculateOverallThreatScore() const {
    float electricalScore = calculateElectricalThreatScore();
    float temperatureScore = calculateTemperatureThreatScore();
    float networkScore = calculateNetworkThreatScore();
    
    // Weighted combination of all threat factors
    return (electricalScore * 0.5f + temperatureScore * 0.3f + networkScore * 0.2f);
}

bool SecurityMetrics::isAnomalyDetected() const {
    return (currentVariation > CURRENT_THRESHOLD) ||
           (voltageVariation > VOLTAGE_THRESHOLD) ||
           (temperatureAnomaly > TEMPERATURE_THRESHOLD) ||
           (powerFactor < POWER_FACTOR_MIN) ||
           networkAnomalyDetected;
}

String SecurityMetrics::getAnomalyDescription() const {
    String description = "";
    
    if (currentVariation > CURRENT_THRESHOLD) {
        description += "High current variation (" + String(currentVariation, 1) + "%) ";
    }
    if (voltageVariation > VOLTAGE_THRESHOLD) {
        description += "High voltage variation (" + String(voltageVariation, 1) + "%) ";
    }
    if (temperatureAnomaly > TEMPERATURE_THRESHOLD) {
        description += "Temperature anomaly (" + String(temperatureAnomaly, 1) + "°C) ";
    }
    if (powerFactor < POWER_FACTOR_MIN) {
        description += "Low power factor (" + String(powerFactor, 2) + ") ";
    }
    if (networkAnomalyDetected) {
        description += "Network communication issues ";
    }
    
    if (description.length() == 0) {
        description = "No anomalies detected";
    }
    
    return description;
}

// Statistical methods
void SecurityMetrics::resetStatistics() {
    totalEvents = 0;
    threatEvents = 0;
    averageThreatLevel = 0.0f;
    maxThreatLevel = 0.0f;
    updateCount = 0;
    threatLevelSum = 0.0f;
    lastUpdateTime = millis();
    
    // Clear history
    for (int i = 0; i < THREAT_HISTORY_SIZE; i++) {
        threatHistory.push(0.0f);
    }
}

float SecurityMetrics::getThreatLevelTrend() const {
    if (threatHistory.size() < 10) return 0.0f;
    
    // Calculate trend over last 10 readings
    float recent = 0.0f;
    float older = 0.0f;
    
    for (int i = 0; i < 5; i++) {
        recent += threatHistory.get(threatHistory.size() - 1 - i);
        older += threatHistory.get(threatHistory.size() - 6 - i);
    }
    
    return (recent - older) / 5.0f;
}

unsigned long SecurityMetrics::getEventCount() const { 
    return totalEvents; 
}

float SecurityMetrics::getAverageThreatLevel() const { 
    return averageThreatLevel; 
}

// Timestamp management
unsigned long SecurityMetrics::getLastUpdateTime() const { 
    return lastUpdateTime; 
}

void SecurityMetrics::updateTimestamp() { 
    lastUpdateTime = millis();
    uptime = (millis() - systemStartTime) / 1000;
}

// Get detailed statistics
String SecurityMetrics::getDetailedStats() const {
    String stats = "Security Metrics Summary:\n";
    stats += "Total Events: " + String(totalEvents) + "\n";
    stats += "Threat Events: " + String(threatEvents) + "\n";
    stats += "Avg Threat Level: " + String(averageThreatLevel, 2) + "\n";
    stats += "Max Threat Level: " + String(maxThreatLevel, 2) + "\n";
    stats += "Uptime: " + String(uptime) + "s\n";
    stats += "Current Variation: " + String(currentVariation, 2) + "%\n";
    stats += "Voltage Variation: " + String(voltageVariation, 2) + "%\n";
    stats += "Temperature Anomaly: " + String(temperatureAnomaly, 2) + "°C\n";
    stats += "Power Factor: " + String(powerFactor, 3) + "\n";
    stats += "Network Anomaly: " + String(networkAnomalyDetected ? "Yes" : "No") + "\n";
    return stats;
}

// Private methods
float SecurityMetrics::calculateElectricalThreatScore() const {
    float score = 0.0f;
    
    // Current variation threat
    if (currentVariation > CURRENT_THRESHOLD) {
        score += min(50.0f, (currentVariation - CURRENT_THRESHOLD) * 2.0f);
    }
    
    // Voltage variation threat
    if (voltageVariation > VOLTAGE_THRESHOLD) {
        score += min(30.0f, (voltageVariation - VOLTAGE_THRESHOLD) * 1.5f);
    }
    
    // Power factor threat
    if (powerFactor < POWER_FACTOR_MIN) {
        score += (POWER_FACTOR_MIN - powerFactor) * 100.0f;
    }
    
    return min(100.0f, score);
}

float SecurityMetrics::calculateTemperatureThreatScore() const {
    if (temperatureAnomaly > TEMPERATURE_THRESHOLD) {
        return min(100.0f, (temperatureAnomaly - TEMPERATURE_THRESHOLD) * 2.0f);
    }
    return 0.0f;
}

float SecurityMetrics::calculateNetworkThreatScore() const {
    return networkAnomalyDetected ? 25.0f : 0.0f;
}

void SecurityMetrics::updateStatistics(float threatScore) {
    totalEvents++;
    updateCount++;
    threatLevelSum += threatScore;
    averageThreatLevel = threatLevelSum / updateCount;
    
    if (threatScore > 50.0f) {  // High threat threshold
        threatEvents++;
    }
}