/*
 * DisplayManager.h - TFT Display Management Library
 * 
 * This library handles the 1.8" TFT display for the EV-Secure system.
 * It provides real-time status display, alerts, and system information.
 */

#ifndef DISPLAY_MANAGER_H
#define DISPLAY_MANAGER_H

#include "EV_Secure_Config.h"
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <SPI.h>

// Display colors (ST7735 color format)
#define COLOR_BLACK    0x0000
#define COLOR_WHITE    0xFFFF
#define COLOR_RED      0xF800
#define COLOR_GREEN    0x07E0
#define COLOR_BLUE     0x001F
#define COLOR_YELLOW   0xFFE0
#define COLOR_CYAN     0x07FF
#define COLOR_MAGENTA  0xF81F
#define COLOR_ORANGE   0xFC00
#define COLOR_PURPLE   0x8000
#define COLOR_GRAY     0x8410
#define COLOR_DARK_GRAY 0x4208

// Display layout constants
#define HEADER_HEIGHT 20
#define STATUS_BAR_HEIGHT 15
#define CONTENT_HEIGHT (TFT_HEIGHT - HEADER_HEIGHT - STATUS_BAR_HEIGHT)
#define SENSOR_ROWS 5
#define SENSOR_ROW_HEIGHT (CONTENT_HEIGHT / SENSOR_ROWS)

// Display states
enum DisplayState {
  DISPLAY_STARTUP,
  DISPLAY_NORMAL,
  DISPLAY_ALERT,
  DISPLAY_ERROR,
  DISPLAY_LOCKDOWN
};

class DisplayManager {
public:
  DisplayManager(int8_t cs, int8_t dc, int8_t rst);
  ~DisplayManager();
  
  // Initialization
  bool init();
  
  // Display updates
  void updateDisplay(const SensorData& sensorData, const MLPrediction& mlResult);
  void showStartupScreen();
  void showLockdownScreen();
  void clearScreen();
  void setBrightness(uint8_t brightness);
  
  // Status indicators
  bool isInitialized() const { return _initialized; }
  
  // Static utility functions
  static void showErrorScreen(const String& error);
  static void showAlertScreen(const String& alert);

private:
  // Instance variables
  bool _initialized;
  Adafruit_ST7735 _tft;
  DisplayState _currentState;
  unsigned long _lastUpdate;
  String _lastSessionId;
  bool _lastChargingState;
  bool _lastThreatState;
  
  // Helper functions
  void _drawHeader();
  void _drawSensorData(const SensorData& sensorData);
  void _drawMLStatus(const MLPrediction& mlResult);
  void _drawStatusBar();
  void _drawCenteredText(int y, const String& text, uint16_t color = COLOR_WHITE, uint8_t size = 1);
  void _drawProgressBar(int x, int y, int width, int height, float progress, uint16_t color);
};

#endif // DISPLAY_MANAGER_H