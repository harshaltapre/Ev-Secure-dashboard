/*
 * MLModel.cpp - Machine Learning Model Implementation
 * 
 * This file implements the MLModel class for threat detection in the EV-Secure system.
 * It uses a hybrid approach combining rule-based detection with lightweight neural networks.
 */

#include "MLModel.h"

// Constructor
MLModel::MLModel() : _initialized(false), _modelSize(0) {
}

// Initialize ML model
bool MLModel::init() {
  if (_initialized) {
    return true;
  }
  
  Serial.println("Initializing ML Model...");
  
  // Initialize model weights (simplified for Arduino)
  _initializeWeights();
  
  _initialized = true;
  _modelSize = sizeof(_modelWeights);
  
  Serial.println("ML Model initialized successfully");
  Serial.println("Model size: " + String(_modelSize) + " bytes");
  
  return true;
}

// Run inference on sensor data
bool MLModel::runInference(const SensorData& sensorData, MLPrediction* result) {
  if (!_initialized || !result) {
    return false;
  }
  
  // Extract features from sensor data
  float features[FEATURE_COUNT];
  extractFeatures(sensorData, features);
  
  // Run neural network inference
  float neuralPrediction = runNeuralNetwork(features);
  
  // Run rule-based detection
  float ruleBasedScore = runRuleBasedDetection(sensorData);
  
  // Combine predictions (weighted average)
  float combinedPrediction = (neuralPrediction * 0.7) + (ruleBasedScore * 0.3);
  
  // Determine anomaly type
  AnomalyType anomalyType = determineAnomalyType(sensorData, combinedPrediction);
  
  // Fill result
  result->prediction = combinedPrediction;
  result->confidence = calculateConfidence(combinedPrediction, neuralPrediction, ruleBasedScore);
  result->anomalyType = anomalyType;
  
  return true;
}

// Extract features from sensor data
void MLModel::extractFeatures(const SensorData& sensorData, float* features) {
  if (!features) return;
  
  // Normalize features to 0-1 range
  features[0] = sensorData.current / MAX_CURRENT;  // Current feature
  features[1] = sensorData.voltage / 500.0f;      // Voltage feature (assuming max 500V)
  features[2] = sensorData.power / 15000.0f;       // Power feature (assuming max 15kW)
  features[3] = sensorData.frequency / 100.0f;     // Frequency feature (assuming max 100Hz)
  
  // Calculate derived features
  features[4] = calculatePowerFactor(sensorData);   // Power factor
  features[5] = calculateCurrentVariation(sensorData); // Current variation
  features[6] = calculateVoltageVariation(sensorData); // Voltage variation
}

// Run neural network inference
float MLModel::runNeuralNetwork(float* features) {
  if (!features) return 0.0f;
  
  // Simple feedforward neural network
  float hidden[8];
  
  // Hidden layer
  for (int i = 0; i < 8; i++) {
    hidden[i] = 0.0f;
    for (int j = 0; j < FEATURE_COUNT; j++) {
      hidden[i] += features[j] * _modelWeights[i * FEATURE_COUNT + j];
    }
    hidden[i] = _relu(hidden[i]);
  }
  
  // Output layer
  float output = 0.0f;
  for (int i = 0; i < 8; i++) {
    output += hidden[i] * _modelWeights[FEATURE_COUNT * 8 + i];
  }
  
  return _sigmoid(output);
}

// Run rule-based detection
float MLModel::runRuleBasedDetection(const SensorData& sensorData) {
  float score = 0.0f;
  
  // Current anomaly detection
  if (sensorData.current > MAX_CURRENT * 0.9) {
    score += 0.3f; // High current
  }
  
  // Voltage anomaly detection
  if (sensorData.voltage < 200.0f || sensorData.voltage > 450.0f) {
    score += 0.4f; // Voltage out of range
  }
  
  // Power anomaly detection
  float expectedPower = sensorData.current * sensorData.voltage;
  float powerDifference = abs(sensorData.power - expectedPower);
  if (powerDifference > expectedPower * 0.1) {
    score += 0.2f; // Power mismatch
  }
  
  // Frequency anomaly detection
  if (sensorData.frequency < 45.0f || sensorData.frequency > 55.0f) {
    score += 0.1f; // Frequency out of range
  }
  
  return min(score, 1.0f);
}

// Determine anomaly type
AnomalyType MLModel::determineAnomalyType(const SensorData& sensorData, float prediction) {
  if (prediction < 0.3f) {
    return ANOMALY_NONE;
  }
  
  if (sensorData.current > MAX_CURRENT * 0.8) {
    return ANOMALY_OVERCURRENT;
  }
  
  if (sensorData.voltage < 200.0f || sensorData.voltage > 450.0f) {
    return ANOMALY_VOLTAGE;
  }
  
  if (sensorData.frequency < 45.0f || sensorData.frequency > 55.0f) {
    return ANOMALY_FREQUENCY;
  }
  
  return ANOMALY_GENERAL;
}

// Calculate confidence
float MLModel::calculateConfidence(float combined, float neural, float ruleBased) {
  // Higher confidence when both methods agree
  float agreement = 1.0f - abs(neural - ruleBased);
  return min(combined * agreement, 1.0f);
}

// Helper functions
float MLModel::calculatePowerFactor(const SensorData& sensorData) {
  if (sensorData.voltage == 0 || sensorData.current == 0) {
    return 0.0f;
  }
  return sensorData.power / (sensorData.voltage * sensorData.current);
}

float MLModel::calculateCurrentVariation(const SensorData& sensorData) {
  // Simplified - in real implementation, you'd track historical data
  static float lastCurrent = 0.0f;
  if (lastCurrent == 0.0f) {
    lastCurrent = sensorData.current;
    return 0.0f;
  }
  
  float variation = abs(sensorData.current - lastCurrent) / lastCurrent;
  lastCurrent = sensorData.current;
  return min(variation, 1.0f);
}

float MLModel::calculateVoltageVariation(const SensorData& sensorData) {
  // Simplified - in real implementation, you'd track historical data
  static float lastVoltage = 0.0f;
  if (lastVoltage == 0.0f) {
    lastVoltage = sensorData.voltage;
    return 0.0f;
  }
  
  float variation = abs(sensorData.voltage - lastVoltage) / lastVoltage;
  lastVoltage = sensorData.voltage;
  return min(variation, 1.0f);
}

// Initialize model weights (simplified random initialization)
void MLModel::_initializeWeights() {
  randomSeed(analogRead(0));
  
  for (int i = 0; i < MODEL_WEIGHT_COUNT; i++) {
    _modelWeights[i] = (random(-100, 100) / 100.0f);
  }
}

// Activation functions
float MLModel::_sigmoid(float x) {
  return 1.0f / (1.0f + exp(-x));
}

float MLModel::_relu(float x) {
  return max(0.0f, x);
}

// Check if model is initialized
bool MLModel::isInitialized() const {
  return _initialized;
}

// Get model size
size_t MLModel::getModelSize() const {
  return _modelSize;
}
