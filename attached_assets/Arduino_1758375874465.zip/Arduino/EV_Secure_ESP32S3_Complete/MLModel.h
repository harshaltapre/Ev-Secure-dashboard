/*
 * MLModel.h - Machine Learning Model Library
 * 
 * This library provides machine learning inference for threat detection
 * in the EV-Secure system using a lightweight neural network.
 */

#ifndef ML_MODEL_H
#define ML_MODEL_H

#include "EV_Secure_Config.h"

// ML model constants
#define FEATURE_COUNT 7
#define HIDDEN_LAYER_SIZE 8
#define OUTPUT_LAYER_SIZE 1
#define MAX_WEIGHTS 64

// Anomaly types
enum AnomalyType {
  ANOMALY_NONE,
  ANOMALY_ELECTRICAL,
  ANOMALY_PROTOCOL,
  ANOMALY_POWER_QUALITY,
  ANOMALY_SECURITY
};

// ML prediction structure
struct MLPrediction {
  float prediction;        // 0.0 to 1.0 (threat level)
  float confidence;        // 0.0 to 1.0 (model confidence)
  AnomalyType anomalyType; // Type of detected anomaly
  unsigned long timestamp; // When prediction was made
};

class MLModel {
public:
  // Constructor
  MLModel();
  
  // Initialization
  bool init();
  
  // Inference
  bool runInference(const SensorData& sensorData, MLPrediction* result);
  
  // Model management
  void cleanup();
  bool isInitialized() const { return _initialized; }
  size_t getModelSize() const { return _modelSize; }
  
  // Feature extraction
  void extractFeatures(const SensorData& sensorData, float* features);
  
  // Neural network functions
  float runNeuralNetwork(float* features);
  float runRuleBasedDetection(const SensorData& sensorData);
  AnomalyType determineAnomalyType(const SensorData& sensorData, float prediction);
  float calculateConfidence(float combined, float neural, float ruleBased);
  
  // Utility functions
  float calculatePowerFactor(float realPower, float apparentPower) {
    if (apparentPower == 0) return 1.0f;
    return realPower / apparentPower;
  }
  
  float calculateCurrentVariation(const SensorData& sensorData);
  float calculateVoltageVariation(const SensorData& sensorData);

private:
  // Instance variables
  bool _initialized;
  float _modelWeights[MAX_WEIGHTS];
  size_t _modelSize;
  
  // Helper functions
  void _initializeWeights();
  float _sigmoid(float x);
  float _relu(float x);
};

#endif // ML_MODEL_H