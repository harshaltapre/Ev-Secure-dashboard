/*
 * SecurityMetrics.h - Security and Threat Detection Metrics Library
 * 
 * This library manages security metrics and threat detection data for the EV-Secure system.
 * It tracks various electrical parameters and their anomalies, calculates threat scores,
 * and provides statistical analysis of security events.
 */

#ifndef SECURITY_METRICS_H
#define SECURITY_METRICS_H

#include "EV_Secure_Config.h"
#include <Arduino.h>

// Constants for threat detection
#define MAX_THREAT_LEVEL 100.0f
#define THREAT_HISTORY_SIZE 100
#define VOLTAGE_THRESHOLD 10.0f     // Percentage variation
#define CURRENT_THRESHOLD 15.0f     // Percentage variation
#define TEMPERATURE_THRESHOLD 50.0f  // Celsius
#define POWER_FACTOR_MIN 0.85f

// Simple circular buffer implementation
template<typename T, size_t N>
class CircularBuffer {
public:
    CircularBuffer() : _head(0), _size(0) {}
    
    void push(const T& value) {
        _buffer[_head] = value;
        _head = (_head + 1) % N;
        if (_size < N) _size++;
    }
    
    T get(size_t index) const {
        if (index >= _size) return T{};
        size_t pos = (_head - _size + index + N) % N;
        return _buffer[pos];
    }
    
    size_t size() const { return _size; }
    
    float average() const {
        if (_size == 0) return 0.0f;
        float sum = 0.0f;
        for (size_t i = 0; i < _size; i++) {
            sum += get(i);
        }
        return sum / _size;
    }
    
    float max() const {
        if (_size == 0) return 0.0f;
        float maxVal = get(0);
        for (size_t i = 1; i < _size; i++) {
            float val = get(i);
            if (val > maxVal) maxVal = val;
        }
        return maxVal;
    }
    
    float min() const {
        if (_size == 0) return 0.0f;
        float minVal = get(0);
        for (size_t i = 1; i < _size; i++) {
            float val = get(i);
            if (val < minVal) minVal = val;
        }
        return minVal;
    }
    
private:
    T _buffer[N];
    size_t _head;
    size_t _size;
};

class SecurityMetrics {
public:
    // Constructor
    SecurityMetrics();
    
    // Core metrics
    float currentVariation;       // Percentage variation from nominal
    float voltageVariation;       // Percentage variation from nominal
    float frequencyDeviation;     // Hz deviation from nominal
    float powerFactor;            // Power factor (0.0-1.0)
    float temperatureAnomaly;     // Degrees above normal
    bool networkAnomalyDetected;  // Network communication issues
    
    // Aggregated statistics
    unsigned long totalEvents;      // Total number of security events
    unsigned long threatEvents;     // Number of high-threat events
    float averageThreatLevel;      // Average threat level
    float maxThreatLevel;          // Maximum threat level seen
    unsigned long uptime;          // System uptime in seconds
    
    // Methods for updating metrics
    void updateElectricalMetrics(float current, float voltage, float frequency);
    void updateTemperature(float temp);
    void updateNetworkStatus(bool anomalyDetected);
    void updateThreatLevel(float newThreatLevel);
    
    // Analysis methods
    float calculateOverallThreatScore() const;
    bool isAnomalyDetected() const;
    String getAnomalyDescription() const;
    
    // Statistical methods
    void resetStatistics();
    float getThreatLevelTrend() const;
    unsigned long getEventCount() const;
    float getAverageThreatLevel() const;
    
    // Timestamp management
    unsigned long getLastUpdateTime() const;
    void updateTimestamp();
    
    // Get detailed statistics
    String getDetailedStats() const;

private:
    // Internal calculation methods
    float calculateElectricalThreatScore() const;
    float calculateTemperatureThreatScore() const;
    float calculateNetworkThreatScore() const;
    void updateStatistics(float threatScore);
    
    // Historical data for trend analysis
    CircularBuffer<float, THREAT_HISTORY_SIZE> threatHistory;
    
    // Reference values
    float nominalCurrent;
    float nominalVoltage;
    float nominalFrequency;
    float normalTemperature;
    
    // Internal counters
    unsigned long updateCount;
    float threatLevelSum;
    unsigned long lastUpdateTime;
    unsigned long systemStartTime;
};

#endif // SECURITY_METRICS_H