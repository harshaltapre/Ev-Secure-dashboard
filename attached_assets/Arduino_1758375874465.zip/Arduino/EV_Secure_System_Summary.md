# EV-Secure ESP32-S3 Charging Station Security Monitoring System

## Overview
This system monitors EV charging sessions for security threats and anomalies using voltage/current sensors, machine learning models, and real-time API communication to a dashboard.

## Core Functionality

### 1. **Sensor Monitoring**
- **Voltage Sensor**: Monitors charging voltage (200V-450V range)
- **Current Sensor**: Monitors charging current (0-30A range)
- **Power Calculation**: Real-time power monitoring
- **Frequency Monitoring**: AC frequency detection (45-55Hz)

### 2. **Threat Detection**
- **Machine Learning Model**: Hybrid approach combining:
  - Lightweight neural network for pattern recognition
  - Rule-based detection for known threats
- **Anomaly Types Detected**:
  - Overcurrent conditions
  - Voltage anomalies (over/under voltage)
  - Frequency deviations
  - Power factor abnormalities
  - General charging anomalies

### 3. **Security Features**
- **Real-time Monitoring**: Continuous sensor data analysis
- **Threat Scoring**: 0-100% threat level calculation
- **Emergency Stop**: Automatic relay cutoff on critical threats
- **Safety Interlocks**: Multiple safety checks before state changes

### 4. **API Communication**
- **Dashboard Integration**: Sends data to Next.js dashboard
- **Real-time Updates**: Continuous data streaming
- **Alert System**: Immediate threat notifications
- **Station Management**: Remote control capabilities

### 5. **Relay Control**
- **Charging Control**: ON/OFF control of charging session
- **Safety Shutdown**: Emergency stop functionality
- **Manual Override**: Manual control capabilities
- **Status Monitoring**: Relay health and feedback

## Hardware Configuration

### ESP32-S3 Pin Mapping
```
Voltage Sensor:    GPIO2 (ADC1_CH1)
Current Sensor:    GPIO1 (ADC1_CH0)
Relay Control:     GPIO18
Emergency Stop:    GPIO16 (INPUT_PULLUP)
Status LED:        GPIO2
TFT Display:       CS=GPIO34, DC=GPIO14, RST=GPIO15
SD Card:           CS=GPIO10, MOSI=GPIO11, MISO=GPIO13, SCK=GPIO12
```

### Sensors Used
- **ACS712 Current Sensor** (30A) or **INA226 Energy Meter**
- **ZMPT101B Voltage Sensor** or **Voltage Divider**
- **1.8" TFT Display** (ST7735/ST7789)
- **Relay Module** for contactor control

## Software Architecture

### Core Classes
1. **SensorManager**: Handles voltage/current sensor readings
2. **MLModel**: Machine learning threat detection
3. **RelayController**: Charging session control
4. **APIManager**: Dashboard communication
5. **DisplayManager**: TFT display management
6. **SecurityMetrics**: Security data tracking
7. **SDLogger**: Data logging to SD card

### Data Flow
```
Sensors → SensorManager → MLModel → Threat Detection
    ↓
SecurityMetrics → APIManager → Dashboard
    ↓
RelayController → Charging Control
```

## Key Features for Your Requirements

### ✅ **Voltage/Current Monitoring**
- Real-time voltage and current measurement
- Power calculation and monitoring
- Frequency detection for AC systems

### ✅ **Threat Detection**
- ML-based anomaly detection
- Rule-based security checks
- Real-time threat scoring

### ✅ **API Communication**
- Secure API key authentication
- Real-time data transmission
- Dashboard integration

### ✅ **Relay Control**
- Charging session ON/OFF control
- Emergency stop functionality
- Safety interlock systems

### ✅ **No Temperature Sensors**
- Focus on electrical parameters only
- Voltage, current, power, frequency monitoring
- Electrical anomaly detection

## OCPP Protocol Security

The system monitors for OCPP protocol vulnerabilities by:
- Detecting unusual charging patterns
- Monitoring for power anomalies
- Identifying potential cyber attacks
- Real-time threat assessment

## Dashboard Integration

The Next.js dashboard receives:
- Real-time sensor data
- Threat level scores
- Anomaly detection results
- Station status information
- Historical data for analytics

## Installation & Usage

1. **Hardware Setup**: Connect sensors and relay as per pin mapping
2. **Arduino IDE**: Upload the complete sketch
3. **Configuration**: Set API keys and station ID
4. **Dashboard**: Access real-time monitoring interface
5. **Monitoring**: Continuous threat detection and alerting

## Security Benefits

- **Real-time Protection**: Immediate threat detection
- **Automated Response**: Automatic safety shutdowns
- **Remote Monitoring**: Dashboard-based oversight
- **Data Logging**: Complete audit trail
- **Scalable**: Multiple station support

This system provides comprehensive security monitoring for EV charging stations, focusing on electrical parameter analysis and threat detection without requiring temperature sensors, exactly as requested.
